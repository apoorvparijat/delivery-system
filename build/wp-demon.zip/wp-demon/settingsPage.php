<script type="text/javascript" src="<?php echo get_option('siteurl') . '/wp-content/plugins/wp-demon/wp-demon-res/jqueryUI/js/jquery-ui-1.8.6.custom.min.js' ?> "></script>
<script type="text/javascript" src="<?php echo get_option('siteurl') . '/wp-content/plugins/wp-demon/wp-demon-res/jqueryUI/colorpicker/js/colorpicker.js' ?> "></script>

<script type="text/javascript">
var active_form = '';
function bindHover(){
    jQuery(".preview-box img").unbind("mouseenter mouseleave");
    jQuery(".preview-box .not-active").hover(
                                             function(){
                                             jQuery(this).css("opacity","1").parent().css("border","1px solid #888");
                                             
                                             },function(){
                                             
                                             jQuery(this).css("opacity","0.6").parent().css("border","1px solid #e8e8e8");
                                             });
}
function showTemplateForm(id){
    
    jQuery("#popup-type").val(id);
    jQuery(".template-form").hide();
    jQuery("#template"+id+"-popup-form").show();
    jQuery("#active_template_value").val(id);
    jQuery(".preview-box img").css("opacity","0.6").addClass("not-active").parent().css("border-color","#e8e8e8").css("box-shadow","0px 0px 1px #999");
    if(id == 4)
        id = 2;
    else if(id == 3)
        id = 4;
    else if(id == 2)
        id = 3;
    elem = jQuery(".preview-box img").get(id-1);
    jQuery(elem).css("opacity","1").removeClass("not-active").parent().css("border-color","#999").css("box-shadow","0px 0px 2px #999");
    bindHover();
}
function syncText(className,value){
    jQuery(".toSync-"+className).each(function(){
                                      jQuery(this).val(value);
                                      });
}

function sendOptions(comp)
{
    jQuery("#loader").css("opacity",1);
    //alert(comp);
    if(comp != 'license'){
        
        
        arr = ['button','button_txt','product_features'];
        
        jQuery('#'+comp+'_act').attr("disabled","true");
        jQuery('#'+comp+'_deact').removeAttr("disabled");
        //jQuery('#'+comp+'_edit').show();
        
        jQuery("#save-"+comp+"").attr("disabled","true").attr("value","Saving..");
        var encoded = encodeURIComponent(document.cookie);
        
        
        
        jQuery.post("<?php echo get_option('siteurl') ?>"+"/wp-admin/admin-ajax.php", jQuery('#'+comp+'-settings').serialize(),
                    function(data)
                    {
                    if(data != "clear")
                    {
                    jQuery('#conflict').html(data)
                    jQuery('#conflict').dialog('open');
                    
                    }
                    //jQuery('#fuzz').css("display","block");
                    setTimeout(function(){
                               //jQuery('#fuzz').fadeOut(400);
                               
                               jQuery("#save-"+comp+"").attr("value","Save").removeAttr("disabled");
                               },300);
                    
                    }
                    );}
    else{
        jQuery("#save-"+comp+"").attr("disabled","true").attr("value","Saving..");
        var encoded = encodeURIComponent(document.cookie);
        jQuery.post("<?php echo get_option('siteurl') ?>"+"/wp-admin/admin-ajax.php", jQuery('#license-verification').serialize(),
                    function(data)
                    {
                    setTimeout(function(){
                               //jQuery('#fuzz').fadeOut(400);
                               
                               jQuery("#save-"+comp+"").hide();
                               jQuery("#reload-verification").show();
                               
                               },300);
                    
                    }
                    );
    }
    setTimeout(function(){jQuery('#loader').animate({"opacity":"0"})},200);
}

function deactivate(comp)
{
    jQuery("#loader").css("opacity",1);
    
    //TODO Check for admin rights.
    var encoded = encodeURIComponent(document.cookie);
    jQuery.post("<?php echo get_option('siteurl') ?>"+"/wp-admin/admin-ajax.php", { action : 'deact','component': comp},
                function (data){
                }
                );
    jQuery('#'+comp+'_act').removeAttr("disabled");
    jQuery('#'+comp+'_deact').attr("disabled","true");
    setTimeout(function(){jQuery('#loader').animate({"opacity":"0"})},200);
}
function load_button(comp)
{
    
    if(jQuery('#'+comp+'-settings').css("display") == 'none'){
        jQuery('#'+comp+'-settings').fadeIn("fast");
        //jQuery('#pf').fadeIn("fast");
    }
    
    jQuery('#'+comp+'_deact').removeAttr("disabled");
    active_comp=comp;
    jQuery('#forms').fadeIn();
}

function process_enabled(comp,bool)
{
    if(bool == "yes"){
        jQuery('#'+comp+'_act').attr("disabled","true");
        //jQuery('#'+comp+'_edit').show();
        jQuery('#'+comp+'_deact').removeAttr("disabled");
    }else
    {
        jQuery('#'+comp+'_act').show();
        //jQuery('#'+comp+'_edit').hide();
        jQuery('#'+comp+'_deact').attr("disabled","true");
    }
}
function parse_form(){
    
    jQuery('#name-field-radio, #email-field-radio').html('');
    var tags = ['a','iframe','frame','frameset','script'], reg, val = jQuery('#surfspopupform').val(),
    form = jQuery('#appendHere'), action = jQuery('#formactioninput'), parsed_form = jQuery('#parsed');
    action.val('');parsed_form.html('');form.html('');
    for(var i=0;i<5;i++){
        reg = new RegExp('<'+tags[i]+'([^<>+]*[^\/])>.*?</'+tags[i]+'>', "gi");
        val = val.replace(reg,'');
        
        reg = new RegExp('<'+tags[i]+'([^<>+]*)>', "gi");
        val = val.replace(reg,'');
    }
    tmpval = '';
    try {
        tmpval = decodeURIComponent(val);
    } catch(err){
        tmpval = val;
    }
    form.html(tmpval);
    var count = 1;
    jQuery(':text',form).each(function(){
                              var name = jQuery(this).attr('name');name_selected = name == jQuery('#name-field-selected').val() ? 'checked="checked"' : '';email_selected = name == jQuery('#email-field-selected').val() ? 'checked="checked"' : '';
                              jQuery('#name-field-radio').append('<input type="radio" id = "name-radio'+count+ '" name="inputsname" value="'+name+'" '+name_selected+'/><label for ="name-radio'+count+'">'+name+'</label>');
                              jQuery('#email-field-radio').append('<input type="radio" id = "email-radio'+count+ '" name="inputsemail" value="'+name+'" '+email_selected+'/><label for ="email-radio'+count+'">'+name+'</label>');
                              count++;
                              jQuery('#name-field-radio').buttonset();
                              jQuery('#email-field-radio').buttonset();
                              });
    jQuery(':input',form).each(function(){
                               if(typeof jQuery(this).attr('name') != 'undefined'){
                               parsed_form.append(jQuery('<input type="hidden" name="ffn[]" />').val(jQuery(this).attr('name')));
                               parsed_form.append(jQuery('<input type="hidden" name="ffv[]" />').val(jQuery(this).val()));
                               }
                               });
    jQuery('img',form).each(function(){
                            parsed_form.append(jQuery('<input type="hidden" name="ffi[]" />').val(jQuery(this).attr('src')));
                            });
    action.val(jQuery('form',form).attr('action'));
    form.html('');
}

function changeTemplate(id)
{
    jQuery('#slide_style').attr("value","template"+id);
    jQuery('.template-active').removeClass('template-active');
    jQuery('#template'+id).addClass("template-active");
    if(id == 3){
        jQuery('.for-template3-use').hide();
        
    }
    else
        jQuery('.for-template3-use').show();
    
    
    if(id == 2){
        
        jQuery('.anti-template3-use').show();
        
    }
    else{
        
        jQuery('.anti-template3-use').hide();
    }
    if(id == 4)
        jQuery('.for-template4-use').hide();
    else
        jQuery('.for-template4-use').show();
}



function showForm(id)
{
    formArr = ['button-settings','button_text-settings','product_features-settings','popup-settings'];
    for(var form in formArr)
    {
        if(!isNaN(form))
        jQuery('#'+formArr[form]).hide();
    }
    jQuery('#'+id+'-settings').fadeIn('fast');
}


function count(elem,id)
{
    limit = id;
    text = elem.value;
    diff = limit - (text.length);
    if(diff < 0)
    {
        jQuery(elem).val(jQuery(elem).val().substring(0,limit));
    }
    par = jQuery(elem).parent();
    jQuery('.count',par).html(" Remaining " + (diff) + " of " + limit);
}
function handleAccordion(elem){
    parent = jQuery(elem).parent();
    body = jQuery(".acc-body",parent);
    if(body.css("display") == "none")
        body.slideDown("fast");
    else
        body.slideUp("fast");
}
jQuery(document).ready(function(){
                       jQuery(".checkbox-select-all").click(function(){
                            status = jQuery(this).attr("checked");
                            elem = jQuery(this).parent().parent().parent();
                            if(status == "checked")
                                jQuery("input[type=checkbox]",elem).attr("checked","checked");
                            else
                                jQuery("input[type=checkbox]",elem).removeAttr("checked");
                       });
                       jQuery(".wp-demon-acc .acc-head").click(function(){handleAccordion(this);});
                       activePopupTemplate = jQuery("#popup-type").val();
                       showTemplateForm(activePopupTemplate);
                       
                       
                       //jQuery.cookie("name","apoorv",{ expires: 7 });
                       jQuery('#count-dialog-exceed').dialog({
                                                             autoOpen: false,
                                                             width: 600,
                                                             buttons: {
                                                             "Ok": function() {
                                                             jQuery(this).dialog("close");
                                                             }
                                                             }
                                                             });
                       jQuery('#conflict').dialog({
                                                  autoOpen: false,
                                                  width: 600,
                                                  buttons: {
                                                  "Ok": function() {
                                                  jQuery(this).dialog("close");
                                                  }
                                                  }
                                                  });
jQuery('#template1-screen,#template2-screen,#template3-screen,#template4-screen').dialog({
        autoOpen: false,
        width: 830,
        height:505,
        buttons: {
            "Ok": function() {
                jQuery(this).dialog("close");
                            }
                    }
        });
jQuery('#button-image-gallery').dialog({
            autoOpen: false,
            width: 850,
            height:550,
            buttons: {
                    "Ok": function() {
                        jQuery(this).dialog("close");
                        }
                    }
            });
                       
                       
                       jQuery('#template1-details').button();
                       jQuery('#template1-details').click(function(){id = jQuery("#popup-type").val();jQuery('#template'+id+'-screen').dialog('open');});
                       jQuery('#button-gallery-open').button();
                       jQuery('#button-gallery-open').click(function(){jQuery('#button-image-gallery').dialog('open');});
                       jQuery('.button-img-select').click(function(){jQuery('#button-img-select').val(jQuery(this).attr('title'));});
                       jQuery( "#slider" ).slider({
                                                  value:jQuery('#bt-opacity').val(),
                                                  min: 0,
                                                  max: 1,
                                                  step: 0.1,
                                                  range:"min",
                                                  slide: function( event, ui ) {
                                                  jQuery( "#bt-opacity" ).val(ui.value );
                                                  }
                                                  });
                       
                       
                       jQuery('.picker-overload').ColorPicker({
                                                              onSubmit: function(hsb, hex, rgb, el) {
                                                              jQuery(el).val(hex);
                                                              jQuery(el).css("background-color",'#'+hex);
                                                              jQuery(el).css("color",'#'+hex);
                                                              jQuery(el).ColorPickerHide();
                                                              },
                                                              onBeforeShow: function () {
                                                              jQuery(this).ColorPickerSetColor(this.value);
                                                              }
                                                              });
                       jQuery('#text-decor').buttonset();
                       jQuery('.text-decor').buttonset();
                       
                       
                       jQuery('#addSlide').click(function(){changeSlideCount('add')});
                       jQuery('#removeSlide').click(function(){changeSlideCount('remove')});
                       var button_text_enabled = "<?php
                       $surfsUpOption = $this->fetchSurfsUpOptions('');
                       if(in_array($surfsUpOptions_btn_text['name'],$surfsUpOption[$surfsUpOptions_btn_text['placeholder']]))
                       {
                       echo "yes";
                       }
                       ?>";
                       var button_enabled = "<?php
                       if(in_array($surfsUpOptions_btn['name'],$surfsUpOption[$surfsUpOptions_btn['placeholder']]))
                       {
                       echo "yes";
                       }
                       ?>";
                       
                       var product_features_enabled = "<?php
                       if(in_array($surfsUpOptions_pf['name'],$surfsUpOption[$surfsUpOptions_pf['placeholder']]))
                       {
                       echo "yes";
                       }
                       ?>";
                       
                       var popup_enabled = "<?php
                       if(in_array($surfsUpOptions_popup['name'],$surfsUpOption[$surfsUpOptions_popup['placeholder']]))
                       {
                       echo "yes";
                       }
                       ?>";
                       jQuery('#surfspopupform').change(parse_form);
                       parse_form();
                       process_enabled('product_features',product_features_enabled);
                       process_enabled('button_text',button_text_enabled);
                       process_enabled('button',button_enabled);
                       process_enabled('popup',popup_enabled);
                       setTimeout(function(){jQuery('#loader').animate({"opacity":"0"})},200);
                       jQuery('.comp-list-sidebar-btn').click(
                                                         function(){
                                                              
                                                         jQuery('.comp-list-sidebar-btn').removeClass('nav-active');

                                                         jQuery(this).addClass('nav-active');
                                                    
                                                         showForm(jQuery(this).attr('desc'));
                                
                                                         }
                                                        
                                                         );
                       showForm("popup");
                       
                       });

</script>
<?php
    if(floatval($ver) < floatval($file))
        $update_msg = "A new version is available. Visit &nbsp;<a target=\"_blank\" href=\"http://wp-demon.com\">http://wp-demon.com/</a>";
    else
        $update_msg = "";
?>
<h2 class="plugin-heading">WP Demon <img alt ="Loading.." id="loader" title="loading" style="position:absolute;margin-top:-7px;margin-left:10px;" src="<?php echo get_option('siteurl').'/wp-content/plugins/wp-demon/wp-demon-res/images/ajax-loader.gif';?>" /><div class="update-msg"><?php echo $update_msg; ?></div></h2>

<div id="top-level-container">
<div class="wp-demon-container-header">
    Hellow
</div>
<div id="comp-container">
    <div id="comp-list-side-bar">
        <div class="comp-list-sidebar-btn btn-active nav-active" desc="popup">
            Pop Up
        </div>
        <div class="comp-list-sidebar-btn btn-active" desc="button_text">
            Notification Bar
        </div>
        <div class="comp-list-sidebar-btn btn-active" desc="button">
Buy Now Button
        </div>


    </div>
</div><!-- comp-container close -->


<div id="forms" class="ui-corner-bottom ">
<form method="post" action="" id="button-settings">
<div id="control-buttons">
<input type="button" id="button_act" value="Save Settings and Activate" class="button-primary" onclick="sendOptions('button')">
<input type="button" id="button_deact" value="Deactivate" class="button-primary" onclick="deactivate('button')">
</div>
<br />
<div id="button-image-gallery" title="Button Image">
<img class="button-img-select ui-corner-all" title="wp-content/plugins/wp-demon/wp-demon-res/images/buy.png" src="<?php echo get_option('siteurl').'/wp-content/plugins/wp-demon/wp-demon-res/images/buy.png';?>" />
<img class="button-img-select ui-corner-all" title="wp-content/plugins/wp-demon/wp-demon-res/images/buy-top.png" src="<?php echo get_option('siteurl').'/wp-content/plugins/wp-demon/wp-demon-res/images/buy-top.png';?>" />
<img class="button-img-select ui-corner-all" title="wp-content/plugins/wp-demon/wp-demon-res/images/get-it-now-1.png" src="<?php echo get_option('siteurl').'/wp-content/plugins/wp-demon/wp-demon-res/images/get-it-now-1.png';?>" />
<img class="button-img-select ui-corner-all" title="wp-content/plugins/wp-demon/wp-demon-res/images/get-it-now-top-1.png" src="<?php echo get_option('siteurl').'/wp-content/plugins/wp-demon/wp-demon-res/images/get-it-now-top-1.png';?>" />
<img class="button-img-select ui-corner-all" title="wp-content/plugins/wp-demon/wp-demon-res/images/get-it-now-2.png" src="<?php echo get_option('siteurl').'/wp-content/plugins/wp-demon/wp-demon-res/images/get-it-now-2.png';?>" />
<img class="button-img-select ui-corner-all" title="wp-content/plugins/wp-demon/wp-demon-res/images/get-it-now-top-2.png" src="<?php echo get_option('siteurl').'/wp-content/plugins/wp-demon/wp-demon-res/images/get-it-now-top-2.png';?>" />
</div>
<div class="wp-demon-acc">
    <div class="acc-head make-bold">Button Image</div>
    <div class="acc-body">
    <div class="subpara">
    Select Image : <div id="button-gallery-open" class="button-primary" style="margin-top:3px;margin-bottom:3px;padding:2px;">Image Gallery</div><br />
    Custom Image URL  &nbsp;<input id="button-img-select" class="wide-input-box" type="text" name="image" value="<?php echo $surfsUpOptions_btn['image'] ?>"/>
    </div>
    <div class="paragraph">
        <span class="subpara">
        Buy button links to <input class="wide-input-box" type="text" name="image_link" value="<?php echo $surfsUpOptions_btn['image_link'] ?>"/>
        </span><br />
        <span class="subpara">
        Position of the image <div class="buy-radios" style="margin-left:129px;margin-top:-18px;"><input type="radio" name="image_position"  value="left" <?php if ($surfsUpOptions_btn['image_position'] == 'left')
    echo "checked"; ?>/>&nbsp;Left&nbsp;<br /><input type="radio" name="image_position"  value="center" <?php if ($surfsUpOptions_btn['image_position'] == 'center')
        echo "checked"; ?>/>&nbsp;Center&nbsp;<br /><input type="radio" name="image_position"  value="right" <?php
            if ($surfsUpOptions_btn['image_position'] == "right") {
                echo "checked";
            } ?>/>&nbsp;Right&nbsp;</div>
        </span>
    </div>
    </div>
</div>
<div class="wp-demon-acc">
<div class="acc-head make-bold">Animation Details </div>
<div class="acc-body">
<div class="subpara">
Slide Out Height <input style="width:45px" type="text" name="slideout_height" value="<?php echo $surfsUpOptions_btn['slideout_height'] ?>"/> px
</div>
<div class="subpara">
Time delay after which the button slides in <input type="text" style="width:35px;" name="animation_delay" value="<?php echo $surfsUpOptions_btn['animation_delay'] ?>" /> seconds
</div>
<div class="subpara">
Button is displayed once in <input type="text" style="width:35px;" name="cookie-timeout" value="<?php echo $surfsUpOptions_btn['cookie-timeout'] ?>" /> days
</div>
<div class="subpara">
Button slides in from <div class="buy-radios" style="margin-top:-18px;margin-left:127px;"><input id="button-ph" type="radio" name="placeholder"  value="top" <?php if ($surfsUpOptions_btn['placeholder'] == 'top')echo "checked"; ?>/>&nbsp;Top<br/>
<input id="button-ph" type="radio" name="placeholder"  value="bottom" <?php if ($surfsUpOptions_btn['placeholder'] == 'bottom')echo "checked"; ?>/>&nbsp;Bottom&nbsp;</div>
</div>
</div>
</div>
<div class="wp-demon-acc">
<div class="acc-head make-bold">Show on</div>
<div class="acc-body">
<span style="font-weight:normal">Pages : </span>
<div class="subpara" style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<?php   $old = error_reporting(0); echo $this->page_list_recursive(0, '', unserialize($surfsUpOptions_btn['pages']),'btn');?>
</div>
<span style="font-weight:normal">Posts in Categories : </span>
<div class="subpara" style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<?php echo $this->cat_list_recursive(0, unserialize($surfsUpOptions_btn['categories']),'btn'); ?>
</div>
<span style="font-weight:normal">Categories Pages: </span>
<div class="subpara" style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<?php echo $this->cat_pages_list_recursive(0, unserialize($surfsUpOptions_btn['cat_pages']),'btn'); ?>
</div>
</div><!-- close subpara -->
</div><!-- paragraph -->
<br />
<input type="button" class="button-primary" id="save-button" value="Save" onclick="sendOptions('button');">
<input type="hidden" name="action" value="surfs"/>
<input type="hidden" name="name" value="<?php echo $surfsUpOptions_btn['name'] ?>"/>
<input type="hidden" name="formal-name" value="<?php echo $surfsUpOptions_btn['formal-name'] ?>"/>
<input type="hidden" name="enabled" value="yes"/>
<input type="hidden" name="animation_style" value="<?php echo $surfsUpOptions_btn['animation_style'] ?>"/>
<input type="hidden" name="db" value="<?php echo $this->dbOptionName_button; ?>"/>
</form><!-- button-settings form closed -->

<!------------------- button_text-settings starts -------------------->

<form method="post" action="" id="button_text-settings" style="display:none;">
<div id="control-buttons">
<input type="button" id="button_text_act" value="Save Settings and Activate" class="button-primary" onclick="sendOptions('button_text')">
<input type="button" id="button_text_deact" value="Deactivate" class="button-primary" onclick="deactivate('button_text')">
</div>
<br />
<div class="paragraph hidden">
<span class="make-bold">Offer Image URL</span> &nbsp; <input class="wide-input-box" type="text" name="image" value="<?php echo $surfsUpOptions_btn_text['image'] ?>"/>
</div>
<div class="wp-demon-acc">
<div class="acc-head make-bold">Offer Details</div>
<div class="acc-body">
<span class="subpara">
Offer Text links to <input class="wide-input-box" type="text" name="image_link" value="<?php echo $surfsUpOptions_btn_text['image_link'] ?>"/>
</span><br />
<span class="subpara hidden">
Position of the image <div class="buy-text-radios" style="margin-left:175px;margin-top:-18px;"><input type="radio" name="image_position"  value="left" <?php if ($surfsUpOptions_btn_text['image_position'] == 'left')
    echo "checked"; ?>/>&nbsp;Left&nbsp;<br /><input type="radio" name="image_position"  value="center" <?php if ($surfsUpOptions_btn_text['image_position'] == 'center')
        echo "checked"; ?>/>&nbsp;Center&nbsp;<br /><input type="radio" name="image_position"  value="right" <?php
            if ($surfsUpOptions_btn_text['image_position'] == "right") {
                echo "checked";
            } ?>/>&nbsp;Right&nbsp;</div>
</span>
<div class="subpara" style="margin-top:3px;">
Text/HTML<br /><textarea  cols="50" rows="3"  name="text"><?php echo $surfsUpOptions_btn_text['text'] ?></textarea>
</div>
<div class="subpara">
Font
<div style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<div>Color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_btn_text['bt-color'];?>;color:<?php echo '#'.$surfsUpOptions_btn_text['bt-color'];?>" type="text" name="bt-color" value="<?php echo $surfsUpOptions_btn_text['bt-color']; ?>"/></div>
<div>Size : <input type="text" style="width:35px" name="bt-size" value="<?php echo $surfsUpOptions_btn_text['bt-size']; ?>"/> px</div>
<div id="text-decor" style="margin:3px 0px;">Style : <input id="bt-bold" type="checkbox" name="bold" value="font-weight:bold;" <?php if($surfsUpOptions_btn_text['bold']) echo "checked";?>/><label for="bt-bold"> B</label>
<input id="bt-italic" type="checkbox" name="italic" value="font-style:italic;" <?php if($surfsUpOptions_btn_text['italic']) echo "checked";?>/><label for="bt-italic"> I</label>
<input id="bt-underline" type="checkbox" name="underline" value="text-decoration:underline;" <?php if($surfsUpOptions_btn_text['underline']) echo "checked";?>/><label for="bt-underline"> U</label>
</div>
<div>Background Color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_btn_text['bt-bcolor'];?>;color:<?php echo '#'.$surfsUpOptions_btn_text['bt-bcolor'];?>" type="text" name="bt-bcolor" value="<?php echo $surfsUpOptions_btn_text['bt-bcolor']; ?>"/></div>
<div>Padding : <input type="text" style="width:35px" name="padding" value="<?php echo $surfsUpOptions_btn_text['padding']; ?>"/> px</div>
</div>
</div><!-- close sub para -->
<div class="subpara">
Position of the text <div class="buy-text-radios" style="margin-left:140px;margin-top:-18px;"><input type="radio" name="text_position"  value="left" <?php if ($surfsUpOptions_btn_text['text_position'] == 'left')
    echo "checked"; ?>/>&nbsp;Left&nbsp;<br /><input type="radio" name="text_position"  value="right" <?php
        if ($surfsUpOptions_btn_text['text_position'] == "right") {
            echo "checked";
        } ?>/>&nbsp;Right&nbsp;&nbsp;<br /><input type="radio" name="text_position"  value="center" <?php
            if ($surfsUpOptions_btn_text['text_position'] == "center") {
                echo "checked";
            } ?>/>&nbsp;Center&nbsp;</div>
</div>
<div class="subpara">
<?php
    $auto_selected = $surfsUpOptions_btn_text['bt-width'] == "auto" ? "checked" : "";
    $percent_selected = $surfsUpOptions_btn_text['bt-width'] == "100%" ? "checked" : "";
    ?>
Width of the Offer bar
<div class="buy-text-radios" style="margin-left:140px;margin-top:-18px;">
<input type="radio" name="bt-width" value="100%" <?php echo $percent_selected; ?>/>&nbsp;Fit to Window <br />
<input type="radio" name="bt-width" <?php echo $auto_selected; ?> value="auto" />&nbsp;Fit to Offer Conent
</div>
</div>
</div><!--close paragraph -->
</div>
<div class="wp-demon-acc">
<div class="acc-head make-bold">Animation Details</div>
<div class="acc-body">
<div class="subpara">
Slide Out Height <input style="width:45px" type="text" name="slideout_height" value="<?php echo $surfsUpOptions_btn_text['slideout_height'] ?>"/> px
</div>
<div class="subpara">
Time delay after which the button slides in <input type="text" style="width:35px;" name="animation_delay" value="<?php echo $surfsUpOptions_btn_text['animation_delay'] ?>" /> seconds
</div>
<div class="subpara">
On Screen Time <input type="text" style="width:35px;" name="onscreen-time" value="<?php echo $surfsUpOptions_btn_text['onscreen-time'] ?>" /> seconds
</div>
<div class="subpara">
Bar is displayed once in <input type="text" style="width:35px;" name="cookie-timeout" value="<?php echo $surfsUpOptions_btn_text['cookie-timeout'] ?>" /> days
</div>
<div class="subpara">Fade Out Opacity  <div id="slider" style="width:300px;"></div> <input id="bt-opacity" type="hidden" name="opacity" value="<?php echo $surfsUpOptions_btn_text['opacity']; ?>" /></div>
<div class="subpara">
Bar slides in from <div class="buy-text-radios" style="margin-top:-18px;margin-left:127px;"><input type="radio" name="placeholder"  value="top" <?php if ($surfsUpOptions_btn_text['placeholder'] == 'top')
    echo "checked"; ?>/>&nbsp;Top&nbsp;<br /><input type="radio" name="placeholder"  value="bottom" <?php if ($surfsUpOptions_btn_text['placeholder'] == 'bottom')
        echo "checked"; ?>/>&nbsp;Bottom&nbsp;</div>
</div>
</div>
</div>
<div class="wp-demon-acc">
<div class="acc-head make-bold">Show on</div>
<div class="acc-body">
<div class="subpara">
<span style="font-weight:normal">Pages : </span>
<div class="subpara" style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<?php    echo $this->page_list_recursive(0, '', unserialize($surfsUpOptions_btn_text['pages']),'btn_text');?>
</div>
<span style="font-weight:normal">Posts in Categories : </span>
<div class="subpara" style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<?php echo $this->cat_list_recursive(0, unserialize($surfsUpOptions_btn_text['categories']),'btn_text'); ?>
</div>
<span style="font-weight:normal">Categories Pages : </span>
<div class="subpara" style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<?php echo $this->cat_pages_list_recursive(0, unserialize($surfsUpOptions_btn_text['cat_pages']),'btn_text'); ?>
</div>
</div>
</div>
</div>
<br />
<input type="button" class="button-primary" id="save-button_text" value="Save" onclick="sendOptions('button_text');">
<input type="hidden" name="action" value="surfs"/>
<input type="hidden" name="name" value="<?php echo $surfsUpOptions_btn_text['name'] ?>"/>
<input type="hidden" name="formal-name" value="<?php echo $surfsUpOptions_btn_text['formal-name'] ?>"/>
<input type="hidden" name="enabled" value="yes"/>
<input type="hidden" name="animation_style" value="<?php echo $surfsUpOptions_btn_text['animation_style'] ?>"/>
<input type="hidden" name="db" value="<?php echo $this->dbOptionName_button_text; ?>"/>
</form><!-- close button-text-setting -->
<div id="appendHere" style="display:none"></div>

<!-- ======================================================== popup form starts ========================================== -->

<form method="post" action="" id="popup-settings" style="display:none;">
<input type="hidden" name="active_template" id="active_template_value" val="<?php echo $surfsUpOptions_popup['active_template']; ?>"/>
<div id="control-buttons">
<input type="button" id="popup_act" value="Save Settings and Activate" class="button-primary" onclick="sendOptions('popup')">
<input type="button" id="popup_deact" value="Deactivate" class="button-primary" onclick="deactivate('popup')">
</div>
<br/>
<div class="wp-demon-acc">
    <div class="acc-head make-bold">Pop Up Template</div>
<div class="acc-body">
    <div class="template-preview-box">
        <div class="content">
        <div class="preview-box" param="1" onclick="showTemplateForm(1)">
        <img width="200" src="../wp-content/plugins/wp-demon/wp-demon-res/images/screenies/previews/1-200.jpg" />
        <br />Template 1
        </div>
        <div class="preview-box" param="4" onclick="showTemplateForm(4)">
            <img width="200" src="../wp-content/plugins/wp-demon/wp-demon-res/images/screenies/previews/4-200.jpg" />
        <br />Template 1 with image
        </div>
        <br /><br />
        <div class="preview-box" param="2" onclick="showTemplateForm(2)">
        <img width="200" src="../wp-content/plugins/wp-demon/wp-demon-res/images/screenies/previews/2-200.jpg" />
        <br />Template 2
        </div>
        <div class="preview-box" param="3" onclick="showTemplateForm(3)">
            <img width="200" src="../wp-content/plugins/wp-demon/wp-demon-res/images/screenies/previews/3-200.jpg" />
        <br />Template 2 with image
        </div><br /><br />
        
</div>
</div><!-- close template-preview-box -->
</div><!-- close wp-demon-acc -->
</div>

<input type="hidden" id="popup-type" name="type" value="<?php echo $surfsUpOptions_popup['type'];?>" />
<div class="wp-demon-acc">
    <div class="acc-head">Template Settings</div>
    <div class="acc-body">
    <div id="template1-details">Template Reference</div>
<!-- ============================================ template1-popup-form starts ============================================= -->

<div id="template1-popup-form" class="template-form">
<div class="subpara">Title of the Pop Up <input type="text" class="toSync-title" onblur="syncText('title',this.value)" id="popup-title-box" onkeyup="count(this,60)" class="wide-input-box" name="title" value="<?php echo $surfsUpOptions_popup['title'] ?>"/><input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template1-title-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template1-title-color'];?>" type="text" name="template1-title-color" value="<?php echo $surfsUpOptions_popup['template1-title-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
</div>
<div class="subpara">Short Text <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template1-para-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template1-para-color'];?>" type="text" name="template1-para-color" value="<?php echo $surfsUpOptions_popup['template1-para-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
<br /><textarea onkeyup="count(this,155)" class="toSync-shorttext" onblur="syncText('shorttext',this.value)" id="short-text-box" cols="60" rows="3" name="para"><?php echo $surfsUpOptions_popup['para'] ?></textarea>
</div>
<div class="subpara">Bullet Points <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template1-bullets-txtc'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template1-bullets-txtc'];?>" type="text" name="template1-bullets-txtc" value="<?php echo $surfsUpOptions_popup['template1-bullets-txtc']; ?>"/>
<div style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<div>
Point 1 <input class="toSync-bp1" onblur="syncText('bp1',this.value)" onkeyup="count(this,130)" id="bullet-point1-box" class="wide-input-box" type="text" name="point1" value="<?php echo $surfsUpOptions_popup['point1'] ?>"/><span class="mark-red count" class="count-disp"></span><br />
</div>
<div>
Point 2 <input class="toSync-bp2" onblur="syncText('bp2',this.value)" onkeyup="count(this,130)" id="bullet-point2-box" class="wide-input-box" type="text" name="point2" value="<?php echo $surfsUpOptions_popup['point2'] ?>"/><span class="mark-red count" class="count-disp"></span><br />
</div>
<div>
Point 3 <input class="toSync-bp3" onblur="syncText('bp3',this.value)" onkeyup="count(this,130)" id="bullet-point3-box" class="wide-input-box" type="text" name="point3" value="<?php echo $surfsUpOptions_popup['point3'] ?>"/><span class="mark-red count" class="count-disp"></span>
</div>
</div>
</div>

<div class="subpara">Form Details<div style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<div>Form Title <input id="form-title-box" class="toSync-formtitle" onblur="syncText('formtitle',this.value)" type="text" onkeyup="count(this,30)" class="wide-input-box" name="form-title" value="<?php echo $surfsUpOptions_popup['form-title'] ?>"/><input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template1-form-title-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template1-form-title-color'];?>" type="text" name="template1-form-title-color" value="<?php echo $surfsUpOptions_popup['template1-form-title-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
</div>
<div>Form Description <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template1-form-desc-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template1-form-desc-color'];?>" type="text" name="template1-form-desc" value="<?php echo $surfsUpOptions_popup['template1-form-desc-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
<br /><textarea onkeyup="count(this,85)" class="toSync-formdesc" onblur="syncText('formdesc',this.value)" id="form-desc" cols="60" rows="3" name="form-desc"><?php echo $surfsUpOptions_popup['form-desc'] ?></textarea>
</div>
<div>Submit Button <div style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
Text : <input type="text" name="submit-text" class="toSync-submit-text" onblur="syncText('submit-text',this.value)" value="<?php echo $surfsUpOptions_popup['submit-text'] ?>"/><input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template1-submit-text-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template1-submit-text-color'];?>" type="text" name="template1-submit-text-color" value="<?php echo $surfsUpOptions_popup['template1-submit-text-color']; ?>"/>
<br /> Background Color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template1-submit-bk'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template1-submit-bk'];?>" type="text" name="template1-submit-bk" value="<?php echo $surfsUpOptions_popup['template1-submit-bk']; ?>"/>

</div>
</div>  
<div>Name Box Default Value <input type="text" class="toSync-name-box" onblur="syncText('name-box',this.value)" name="name-default" value="<?php echo $surfsUpOptions_popup['name-default'] ?>"/></div>
<div>Email Box Default Value <input type="text" class="toSync-email-box" onblur="syncText('email-box',this.value)" name="email-default" value="<?php echo $surfsUpOptions_popup['email-default'] ?>"/></div>
<div>
Form Background Color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template1-form-bkcolor'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template1-form-bkcolor'];?>" type="text" name="template1-form-bkcolor" value="<?php echo $surfsUpOptions_popup['template1-form-bkcolor']; ?>"/>
&nbsp;&nbsp;Form Border Color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template1-form-border'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template1-form-border'];?>" type="text" name="template1-form-border" value="<?php echo $surfsUpOptions_popup['template1-form-border']; ?>"/>
</div>


</div>
</div><!-- form details subpara closed -->
<div style="display:none" class="subpara">Security Note <input type="text" name="security-note"  value="<?php echo $surfsUpOptions_popup['security-note'] ?>"/></div>


<div class="subpara">
Pop Up Border Color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template1-bkcolor'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template1-bkcolor'];?>" type="text" name="template1-bkcolor" value="<?php echo $surfsUpOptions_popup['template1-bkcolor']; ?>"/>
&nbsp;&nbsp;Container color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template1-container-bk'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template1-container-bk'];?>" type="text" name="template1-container-bk" value="<?php echo $surfsUpOptions_popup['template1-container-bk']; ?>"/>
</div>
</div>

<!-- ================================== close template1-popup-form ==================================   -->

<!-- ============================================ template2-popup-form starts ============================================= -->

<div id="template2-popup-form" style="display:none" class="template-form">
<div class="subpara">Title of the Pop Up <input type="text" id="popup-title-box" class="toSync-title" onblur="syncText('title',this.value)" onkeyup="count(this,70)" class="wide-input-box" name="title" value="<?php echo $surfsUpOptions_popup['title'] ?>"/><input class="picker-overload" style="background-color:<?php      echo '#'.$surfsUpOptions_popup['template2-title-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template2-title-color'];?>" type="text" name="template2-title-color" value="<?php echo $surfsUpOptions_popup['template2-titl    e-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
</div>
<div class="subpara">Short Text <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template2-para-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template2-para-color'];?>" type="text" name="template2-para-color" value="<?php echo $surfsUpOptions_popup['template2-para-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
<br /><textarea class="toSync-shorttext" onblur="syncText('shorttext',this.value)" onkeyup="count(this,160)" id="short-text-box" cols="60" rows="3" name="para"><?php echo $surfsUpOptions_popup['para'] ?></textarea>
</div>
<div class="subpara">Bullet Points <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template2-bullets-txtc'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template2-bullets-txtc'];?>" type="text" name="template2-bullets-txtc" value="<?php echo $surfsUpOptions_popup['template2-bullets-txtc']; ?>"/>
<div style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<div>Point 1 <input class="toSync-bp1" onblur="syncText('bp1',this.value)" onkeyup="count(this,185)" id="bullet-point1-box" class="wide-input-box" type="text" name="point1" value="<?php echo $surfsUpOptions_popup['point1'] ?>"/><span class="mark-red count" class="count-disp"></span><br />
</div>
<div>Point 2 <input class="toSync-bp2" onblur="syncText('bp2',this.value)" onkeyup="count(this,185)" id="bullet-point2-box" class="wide-input-box" type="text" name="point2" value="<?php echo $surfsUpOptions_popup['point2'] ?>"/><span class="mark-red count" class="count-disp"></span><br />
</div>
<div>Point 3 <input class="toSync-bp3" onblur="syncText('bp3',this.value)" onkeyup="count(this,180)" id="bullet-point3-box" class="wide-input-box" type="text" name="point3" value="<?php echo $surfsUpOptions_popup['point3'] ?>"/><span class="mark-red count" class="count-disp"></span>
</div>
</div>
</div>
<div class="subpara">Form Details<div style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<div>Form Title <input id="form-title-box" class="toSync-formtitle" onblur="syncText('formtitle',this.value)" type="text" onkeyup="count(this,50)" class="wide-input-box" name="form-title" value="<?php echo $surfsUpOptions_popup['form-title'] ?>"/><input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template2-form-title-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template2-form-title-color'];?>" type="text" name="template2-form-title-color" value="<?php echo $surfsUpOptions_popup['template2-form-title-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
</div>
<div class="subpara" style="display:none">Form Description <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template2-form-desc-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template2-form-desc-color'];?>" type="text" name="template2-form-desc" value="<?php echo $surfsUpOptions_popup['template2-form-desc-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
<br /><textarea onkeyup="count(this,180)" class="toSync-formdesc" onblur="syncText('formdesc',this.value)" id="form-desc" cols="60" rows="3" name="form-desc"><?php echo $surfsUpOptions_popup['form-desc'] ?></textarea>
</div>
<div style="display:none" class="subpara">Security Note <input type="text" name="security-note"  value="<?php echo $surfsUpOptions_popup['security-note'] ?>"/></div>
<div>Submit Button <div style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
Text : <input type="text" name="submit-text" class="toSync-submit-text" onblur="syncText('submit-text',this.value)" value="<?php echo $surfsUpOptions_popup['submit-text'] ?>"/><input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template2-submit-text-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template2-submit-text-color'];?>" type="text" name="template2-submit-text-color" value="<?php echo $surfsUpOptions_popup['template2-submit-text-color']; ?>"/>
<br /> Background Color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template2-submit-bk'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template2-submit-bk'];?>" type="text" name="template2-submit-bk" value="<?php echo $surfsUpOptions_popup['template2-submit-bk']; ?>"/></div>
</div> 
<div>Name Box Default Value <input type="text" class="toSync-name-box" onblur="syncText('name-box',this.value)" name="name-default" value="<?php echo $surfsUpOptions_popup['name-default'] ?>"/></div>
<div>Email Box Default Value <input type="text" class="toSync-email-box" onblur="syncText('email-box',this.value)" name="email-default" value="<?php echo $surfsUpOptions_popup['email-default'] ?>"/></div>

</div>
</div>

<div class="subpara">
Pop Up Border Color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template2-bkcolor'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template2-bkcolor'];?>" type="text" name="template2-bkcolor" value="<?php echo $surfsUpOptions_popup['template2-bkcolor']; ?>"/>
&nbsp;&nbsp;Container color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template2-container-bk'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template2-container-bk'];?>" type="text" name="template2-container-bk" value="<?php echo $surfsUpOptions_popup['template2-container-bk']; ?>"/>
</div>

</div>

<!-- ================================== close template2-popup-form ==================================   -->
<!-- ============================================ template3-popup-form starts ============================================= -->


<div id="template3-popup-form" style="display:none" class="template-form">
<div class="subpara">Title of the Pop Up <input type="text" id="popup-title-box" class="toSync-title" onblur="syncText('title',this.value)" onkeyup="count(this,70)" class="wide-input-box" name="title" value="<?php echo $surfsUpOptions_popup['title'] ?>"/><input class="picker-overload" style="background-color:<?php      echo '#'.$surfsUpOptions_popup['template3-title-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template3-title-color'];?>" type="text" name="template3-title-color" value="<?php echo $surfsUpOptions_popup['template3-title-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
</div>
<div class="subpara">Short Text <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template3-para-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template3-para-color'];?>" type="text" name="template3-para-color" value="<?php echo $surfsUpOptions_popup['template3-para-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
<br /><textarea class="toSync-shorttext" onblur="syncText('shorttext',this.value)" onkeyup="count(this,160)" id="short-text-box" cols="60" rows="3" name="para"><?php echo $surfsUpOptions_popup['para'] ?></textarea>
</div>
<div class="subpara">Image URL
&nbsp;
<input type="text" style="width:400px;" name="template3-image-url" value="<?php echo $surfsUpOptions_popup['template3-image-url'] ?>" />
</div>
<div class="subpara">Bullet Points <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template3-bullets-txtc'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template3-bullets-txtc'];?>" type="text" name="template3-bullets-txtc" value="<?php echo $surfsUpOptions_popup['template3-bullets-txtc']; ?>"/>
<div style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<div>Point 1 <input class="toSync-bp1" onblur="syncText('bp1',this.value)" onkeyup="count(this,160)" id="bullet-point1-box" class="wide-input-box" type="text" name="point1" value="<?php echo $surfsUpOptions_popup['point1'] ?>"/><span class="mark-red count" class="count-disp"></span><br />
</div>
<div>Point 2 <input class="toSync-bp2" onblur="syncText('bp2',this.value)" onkeyup="count(this,160)" id="bullet-point2-box" class="wide-input-box" type="text" name="point2" value="<?php echo $surfsUpOptions_popup['point2'] ?>"/><span class="mark-red count" class="count-disp"></span><br />
</div>
<div>Point 3 <input class="toSync-bp3" onblur="syncText('bp3',this.value)" onkeyup="count(this,160)" id="bullet-point3-box" class="wide-input-box" type="text" name="point3" value="<?php echo $surfsUpOptions_popup['point3'] ?>"/><span class="mark-red count" class="count-disp"></span>
</div>
</div>
</div>
<div class="subpara">Form Details<div style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<div>Form Title <input id="form-title-box" class="toSync-formtitle" onblur="syncText('formtitle',this.value)" type="text" onkeyup="count(this,50)" class="wide-input-box" name="form-title" value="<?php echo $surfsUpOptions_popup['form-title'] ?>"/><input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template3-form-title-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template3-form-title-color'];?>" type="text" name="template3-form-title-color" value="<?php echo $surfsUpOptions_popup['template3-form-title-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
</div>
<div class="subpara" style="display:none">Form Description <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template3-form-desc-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template3-form-desc-color'];?>" type="text" name="template3-form-desc" value="<?php echo $surfsUpOptions_popup['template3-form-desc-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
<br /><textarea onkeyup="count(this,180)" class="toSync-formdesc" onblur="syncText('formdesc',this.value)" id="form-desc" cols="60" rows="3" name="form-desc"><?php echo $surfsUpOptions_popup['form-desc'] ?></textarea>
</div>
<div style="display:none" class="subpara">Security Note <input type="text" name="security-note"  value="<?php echo $surfsUpOptions_popup['security-note'] ?>"/></div>
<div>Submit Button <div style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
Text : <input type="text" name="submit-text" class="toSync-submit-text" onblur="syncText('submit-text',this.value)" value="<?php echo $surfsUpOptions_popup['submit-text'] ?>"/><input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template3-submit-text-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template3-submit-text-color'];?>" type="text" name="template3-submit-text-color" value="<?php echo $surfsUpOptions_popup['template3-submit-text-color']; ?>"/>
<br /> Background Color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template3-submit-bk'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template3-submit-bk'];?>" type="text" name="template3-submit-bk" value="<?php echo $surfsUpOptions_popup['template3-submit-bk']; ?>"/></div>
</div> 
<div>Name Box Default Value <input type="text" class="toSync-name-box" onblur="syncText('name-box',this.value)" name="name-default" value="<?php echo $surfsUpOptions_popup['name-default'] ?>"/></div>
<div>Email Box Default Value <input type="text" class="toSync-email-box" onblur="syncText('email-box',this.value)" name="email-default" value="<?php echo $surfsUpOptions_popup['email-default'] ?>"/></div>

</div>
</div>

<div class="subpara">
Pop Up Border Color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template3-bkcolor'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template3-bkcolor'];?>" type="text" name="template3-bkcolor" value="<?php echo $surfsUpOptions_popup['template3-bkcolor']; ?>"/>
&nbsp;&nbsp;Container color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template3-container-bk'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template3-container-bk'];?>" type="text" name="template3-container-bk" value="<?php echo $surfsUpOptions_popup['template3-container-bk']; ?>"/>
</div>

</div>

<!-- ================================== close template3-popup-form ==================================   -->
<!-- ============================================ template4-popup-form starts ============================================= -->

<div id="template4-popup-form" class="template-form">
<div class="subpara">Title of the Pop Up <input type="text" class="toSync-title" onblur="syncText('title',this.value)" id="popup-title-box" onkeyup="count(this,60)" class="wide-input-box" name="title" value="<?php echo $surfsUpOptions_popup['title'] ?>"/><input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template4-title-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template4-title-color'];?>" type="text" name="template4-title-color" value="<?php echo $surfsUpOptions_popup['template4-title-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
</div>
<div class="subpara">Short Text <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template4-para-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template4-para-color'];?>" type="text" name="template4-para-color" value="<?php echo $surfsUpOptions_popup['template4-para-color']; ?>"/>

<span class="mark-red count" class="count-disp"></span>
<br /><textarea onkeyup="count(this,155)" class="toSync-shorttext" onblur="syncText('shorttext',this.value)" id="short-text-box" cols="60" rows="3" name="para"><?php echo $surfsUpOptions_popup['para'] ?></textarea>
</div>
<div class="subpara">Image URL
&nbsp;
<input type="text" style="width:400px;" name="template4-image-url" value="<?php echo $surfsUpOptions_popup['template4-image-url'] ?>" />
</div>
<div class="subpara">Bullet Points <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template4-bullets-txtc'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template4-bullets-txtc'];?>" type="text" name="template4-bullets-txtc" value="<?php echo $surfsUpOptions_popup['template4-bullets-txtc']; ?>"/>
<div style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<div>Point 1 <input class="toSync-bp1" onblur="syncText('bp1',this.value)" onkeyup="count(this,70)" id="bullet-point1-box" class="wide-input-box" type="text" name="point1" value="<?php echo $surfsUpOptions_popup['point1'] ?>"/><span class="mark-red count" class="count-disp"></span><br />
</div>
<div>Point 2 <input class="toSync-bp2" onblur="syncText('bp2',this.value)" onkeyup="count(this,70)" id="bullet-point2-box" class="wide-input-box" type="text" name="point2" value="<?php echo $surfsUpOptions_popup['point2'] ?>"/><span class="mark-red count" class="count-disp"></span><br />
</div>
<div>Point 3 <input class="toSync-bp3" onblur="syncText('bp3',this.value)" onkeyup="count(this,70)" id="bullet-point3-box" class="wide-input-box" type="text" name="point3" value="<?php echo $surfsUpOptions_popup['point3'] ?>"/><span class="mark-red count" class="count-disp"></span>
</div>
</div>
</div>

<div class="subpara">Form Details<div style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<div>Form Title <input id="form-title-box" class="toSync-formtitle" onblur="syncText('formtitle',this.value)" type="text" onkeyup="count(this,30)" class="wide-input-box" name="form-title" value="<?php echo $surfsUpOptions_popup['form-title'] ?>"/><input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template4-form-title-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template4-form-title-color'];?>" type="text" name="template4-form-title-color" value="<?php echo $surfsUpOptions_popup['template4-form-title-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
</div>
<div>Form Description <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template4-form-desc-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template4-form-desc-color'];?>" type="text" name="template4-form-desc" value="<?php echo $surfsUpOptions_popup['template4-form-desc-color']; ?>"/>
<span class="mark-red count" class="count-disp"></span>
<br /><textarea onkeyup="count(this,85)" class="toSync-formdesc" onblur="syncText('formdesc',this.value)" id="form-desc" cols="60" rows="3" name="form-desc"><?php echo $surfsUpOptions_popup['form-desc'] ?></textarea>
</div>
<div>Submit Button <div style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
Text : <input type="text" name="submit-text" class="toSync-submit-text" onblur="syncText('submit-text',this.value)" value="<?php echo $surfsUpOptions_popup['submit-text'] ?>"/><input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template4-submit-text-color'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template4-submit-text-color'];?>" type="text" name="template4-submit-text-color" value="<?php echo $surfsUpOptions_popup['template4-submit-text-color']; ?>"/>
<br /> Background Color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template4-submit-bk'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template4-submit-bk'];?>" type="text" name="template4-submit-bk" value="<?php echo $surfsUpOptions_popup['template4-submit-bk']; ?>"/>

</div>
</div>  
<div>Name Box Default Value <input type="text" class="toSync-name-box" onblur="syncText('name-box',this.value)" name="name-default" value="<?php echo $surfsUpOptions_popup['name-default'] ?>"/></div>
<div>Email Box Default Value <input type="text" class="toSync-email-box" onblur="syncText('email-box',this.value)" name="email-default" value="<?php echo $surfsUpOptions_popup['email-default'] ?>"/></div>
<div>
Form Background Color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template4-form-bkcolor'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template4-form-bkcolor'];?>" type="text" name="template4-form-bkcolor" value="<?php echo $surfsUpOptions_popup['template4-form-bkcolor']; ?>"/>
&nbsp;&nbsp;Form Border Color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template4-form-border'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template4-form-border'];?>" type="text" name="template4-form-border" value="<?php echo $surfsUpOptions_popup['template4-form-border']; ?>"/>
</div>


</div>
</div><!-- form details subpara closed -->
<div style="display:none" class="subpara">Security Note <input type="text" name="security-note"  value="<?php echo $surfsUpOptions_popup['security-note'] ?>"/></div>


<div class="subpara">
Pop Up Border Color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template4-bkcolor'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template4-bkcolor'];?>" type="text" name="template4-bkcolor" value="<?php echo $surfsUpOptions_popup['template4-bkcolor']; ?>"/>
&nbsp;&nbsp;Container color : <input class="picker-overload" style="background-color:<?php echo '#'.$surfsUpOptions_popup['template4-container-bk'];?>;color:<?php echo '#'.$surfsUpOptions_popup['template4-container-bk'];?>" type="text" name="template4-container-bk" value="<?php echo $surfsUpOptions_popup['template1-container-bk']; ?>"/>
</div>
</div>

<!-- ================================== close template4-popup-form ==================================   -->

</div>
</div><!-- close wp-demon-acc  template settings -->
<div class="wp-demon-acc">
<div class="acc-head make-bold">Pop Up Form</div>
<div class="acc-body">

<div id="service-form" style="float:left"><div class="subpara">Form <br /><textarea name="popupformhtml" style="font-size:11px"   id="surfspopupform" cols="50" rows="15"><?php echo stripslashes($surfsUpOptions_popupform); ?></textarea></div></div>
<div id="box-to-right" class="ui-corner-all">
<h4 style="color:#333">Read before you proceed</h4>
<div style="font-size:11px;color:#333">
After pasting the form, click outside the text box. The script will search for input boxes in the form and display their names below. <br /><br />
By clicking on these names, select the box that best corresponds to :

</div>
<div id="name-boxes" style=""><div style="font-size:11px;margin-top:10px;">Name Field : <div id="name-field-radio" style="margin-left:75px;margin-top: -23px;"></div><input type="hidden" id="name-field-selected" value="<?php echo $surfsUpOptions_popup['inputsname']; ?>"/></div></div><br />
<div id="email-boxes" style=""><div style="font-size:11px;margin-top:3px;margin-bottom: 5px;">Email Field : <div id="email-field-radio" style="margin-left:75px;margin-top: -23px;"></div><input type="hidden" id="email-field-selected" value="<?php echo $surfsUpOptions_popup['inputsemail']; ?>"/></div></div><br />
</div>
<div class="ui-helper-clearfix"></div>
<div class="subpara" style="display:none;">Form URL <input type="text" id="formactioninput" name="inputsaction" value=""/></div>
</div>

</div><!-- close wp-demon-acc pop up form -->
<div class="wp-demon-acc">
<div class="make-bold acc-head">Animation Details</div>
<div class="acc-body">
<div class="subpara">
Time delay after which form pops up <input type="text" class="wide-input-box" style="width:35px" name="animation_delay" value="<?php echo $surfsUpOptions_popup['animation_delay']; ?>" /> seconds.
</div>

<div class="subpara">
Pop Up is displayed once in <input type="text" style="width:35px;" name="cookie-timeout" value="<?php echo $surfsUpOptions_popup['cookie-timeout'] ?>" /> days
</div>
</div>
</div><!-- close accordion for animation details -->

<div class="wp-demon-acc">
<div class="acc-head make-bold">Show on</div>
<div class="acc-body">
<div class="subpara">
<span style="font-weight:normal">Pages : </span>
<div class="subpara" style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<?php echo $this->page_list_recursive(0, '', unserialize($surfsUpOptions_popup['pages']),'popup');?>
</div>
<span style="font-weight:normal">Posts in Categories : </span>
<div class="subpara" style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<?php echo $this->cat_list_recursive(0, unserialize($surfsUpOptions_popup['categories']),'popup'); ?>
</div>
<span style="font-weight:normal">Categories Pages: </span>
<div class="subpara" style="border-left:2px solid #0073EA;margin-left:20px;padding-left:7px;margin-top:8px;padding-bottom: 6px;margin-bottom: 8px;">
<?php echo $this->cat_pages_list_recursive(0, unserialize($surfsUpOptions_popup['cat_pages']),'pp'); ?>
</div>
</div>
</div>
</div>
<br />
<input type="button" class="button-primary" id="save-popup" value="Save" onclick="sendOptions('popup');"/>
<div id="parsed" style="display:none"></div>
<input type="hidden" name="action" value="surfs"/>
<input type="hidden" name="name" value="popup"/>
<input type="hidden" name="formal-name" value="<?php echo $surfsUpOptions_popup['formal-name'] ?>"/>
<input type="hidden" name="placeholder" value="center"/>
<input type="hidden" name="enabled" value="yes"/>
<input type="hidden" name="db" value="<?php echo $this->dbOptionName_popup; ?>"/>

</form><!-- close popup-form -->
</div> <!-- form container ends -->
<div id="warnings">
<div id="template1-screen" title="Template 1"><img src="<?php error_reporting($old); echo get_option('siteurl').'/wp-content/plugins/wp-demon/wp-demon-res/images/screenies/1.png';?>"/>
</div>
<div id="template2-screen" title="Template 2"><img src="<?php error_reporting($old); echo get_option('siteurl').'/wp-content/plugins/wp-demon/wp-demon-res/images/screenies/2.png';?>"/>
</div>
<div id="template3-screen" title="Template 2 with Image"><img src="<?php error_reporting($old); echo get_option('siteurl').'/wp-content/plugins/wp-demon/wp-demon-res/images/screenies/3.png';?>"/>
</div>
<div id="template4-screen" title="Template 1 with Image"><img src="<?php error_reporting($old); echo get_option('siteurl').'/wp-content/plugins/wp-demon/wp-demon-res/images/screenies/4.png';?>"/>
</div>
<div id="conflict" title="ERROR!! Components Conflict"></div>
</div>
</div> <!-- top level container ends -->