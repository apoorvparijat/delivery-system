<?php
/*
 * Plugin Name: WP Demon
 * Version: 3.0
 * Plugin URI: http://www.wp-demon.com
 * Description: WP Demon
 * Author: Apoorv Parijat
 * Author URI: http://www.wp-demon.com
 */



if (!class_exists("SurfsUp")) {

    class SurfsUp {

        var $dbOptionName = "surfsUpOptions";
        var $dbOptionName_button = "surfsUpOptions_button";
        var $dbOptionName_button_text = "surfsUpOptions_button_text";
        var $dbOptionName_product_features = "surfsUpOptions_product_features";
        var $dbOptionName_popup = "surfsUpOptions_popup";
        var $dbOptionName_popupinputs = "surfsUpOptions_popupinputs";
        var $dbOptionName_popupformhtml = "surfsUpOptions_popupformhtml";
        var $dbOptionName_popupffn = "surfsUpOptions_ffn";
        var $dbOptionName_popupffv = "surfsUpOptions_ffv";
        var $dbOptionName_popupffi = "surfsUpOptions_ffi";
        var $dbOptionName_popupff = "surfsUpOptions_ff";
        

        function SurfsUp() {
            
        }

        function init() {
            // Adds default values to database.
            
            $surfsUpOptions = array(
                'left' => 'none',
                'right' => array(),
                'bottom' => array(),
                'top' => array(),
                'center' => array()
            );
            $surfsUpOptions_button_text = array
                (
		'formal-name' => 'Offers/Notification Bar Component',
                'name' => 'button_text',
                'image' => '',
                'image_link' => 'http://www.google.com',
                'image_position' => 'right',
                'text' => 'This is dummy text',
                'slideout_height' => '20',
                'text_position' => 'left',
                'bt-color' => 'ffffff',
                'onscreen-time' => '-1',
                'bt-size' => '20',
                'bt-bcolor'=> '000000',
                'padding' => '6',
                'opacity' => '0.4',
                'animation_delay' => '1.5',
                'cookie-timeout' => '0',
                'animation_style' => 'fade',
                'target' => 'self',
                'exclude-pages' => array(),
                'placeholder' => 'bottom',
                'db' => '',

            );
            $surfsUpOptions_button = array
                (
		'formal-name' => 'Buy Button Component',
                'name' => 'button',
                'image' => 'wp-content/plugins/wp-demon/wp-demon-res/images/buy.png',
                'image_link' => 'http://www.google.com',
                'image_position' => 'right',
                'animation_delay' => '1.5',
                'slideout_height' => '136',
                'animation_style' => 'fade',
                'cookie-timeout' => '0',
                'pages' => array(),
                'categories' => array(),
                'target' => 'self',
                'placeholder' => 'top',
                'db' => ''
            );
 
            $surfsUpOptions_product_features = array
                (
		'formal-name' => 'Product Features Bar Component',
                'name' => 'product_features',
                'height' => '143',
                'buy_link' => 'http://www.google.com',
                'slide1_image' => 'http://apoorvparijat.com/panel.png',
                'slide1_text' => 'This is my first buy button slide',
                'slide2_image' => 'http://www.google.co.in/images/logos/ps_logo2a_cp.png',
                'slide2_text' => 'This is my second buy button slide',
                'slide_count' => '2',
                'animation_delay' => '1.5',
                'animation_style' => 'fade',
                'cookie-timeout' => '0',
                'target' => 'self',
                'width' => 766,
                'placeholder' => 'bottom',
                'slideout_height' => '20',
                'slide_delay' => '8',
                'slide_style' => 'template1',
                'db' => ''
            );

            $surfsUpOptions_popup = array
                (
		'formal-name' => 'Pop Up Component',
                'name' => 'popup',
                'form' => '',
                'title' => 'Free Instant Access',
                'type' => 'template1',
                'template1-bkcolor' => '000000',
                'para' => '',
                'form-title' => 'Subscribe Now',
                'cookie-timeout' => '0',
                'animation_delay' => '5',
                'template1-submit-bk' => '',
                'point1' => '',
                'point2' => '',
                'point3' => 'And more...',
                'template1-title-color' => '000000',
                'template1-form-title-color' => '1a3305',
                'template1-para-color' => '000000',
                'template1-container-bk' => 'f0f0f0',
                'template1-submit-bk' => '3c53d6',
                'template1-submit-text-color' => '',
                'template1-bullets-txtc' => '000000',
                'template1-bkcolor' => '000000',
                'template2-bkcolor' => '000000',
                'template3-bkcolor' => '000000',
                'type' => '1',
                'name-default' => 'Your Name ..',
                'email-default' => 'Your email address...',
                'submit-text' => 'Access Now',
                'placeholder' => 'center',
                'db' => ''
            );


            update_option($this->dbOptionName, $surfsUpOptions);
            update_option($this->dbOptionName_button, $surfsUpOptions_button);
            update_option($this->dbOptionName_popup, $surfsUpOptions_popup);
            update_option($this->dbOptionName_popupformhtml, "");
            update_option($this->dbOptionName_button_text, $surfsUpOptions_button_text);
            update_option($this->dbOptionName_product_features, $surfsUpOptions_product_features);
            update_option($this->dbOptionName_pages, $surfsUpOptions_pages);
        }

        /**
         *
         * Fetches options of the component passed in the parameter.
         * 
         * @param $which Should be either of these : button, button_text, popup
         * @return array of options of the particular component.
         */
        function fetchSurfsUpOptions($which) {
            //Fetches array of values from database.
            $option_name = $this->dbOptionName;
            if ($which != '') {
                $option_name = $this->dbOptionName . '_' . $which;
            } else if ($which == 'none') {
                return;
            }
            $fetchSurfsUpOptions = get_option($option_name);
            if (!empty($fetchSurfsUpOptions)) {
                return $fetchSurfsUpOptions;
            }
            return null;
        }
        // @todo templatize this function
        function generatePopupForm() {
            $surfsUpOptions_popup = $this->fetchSurfsUpOptions('popup');
            $inputs = array('name' => $surfsUpOptions_popup['inputsname']);
            $inputs['email'] = $surfsUpOptions_popup['inputsemail'];
            //echo $surfsUpOptions_popup['active_template'];
            $fields = '';
            $fieldsarr = get_option($this->dbOptionName_popupff);
            if($fieldsarr){
            foreach ($fieldsarr as $a => $b) {
                $c = in_array($a, $inputs);
                if (!$c)
                    $fields .= '<input type="hidden" name="' . $this->format_dead_html($a) . '" value="' . $this->format_dead_html($b) . '" />';
            }}


            $fieldsarr = get_option($this->dbOptionName_popupffi);
            //$fieldsarr = unserialize($f);
            if ($fieldsarr) {
                foreach ($fieldsarr as $b){
                    $fields .= '<div style="display:none"><img src="' . $this->format_dead_html($b) . '" alt="" height="1" width="1" /></div>';
                }
            }

            $url = get_option('siteurl');
            // TODO: escape quotes in generate popup function
            // form action : $surfsUpOptions_popup['inputsaction']
            // form fields : $fields
            // input names : name -> $inputs['name']
            // input fields : email -> $inputs['email']
            $title = addslashes($surfsUpOptions_popup['title']);
            $shortText = addslashes($surfsUpOptions_popup['para']);
            $point1 = addslashes($surfsUpOptions_popup['point1']);
            $point2 = addslashes($surfsUpOptions_popup['point2']);
            $point3 = addslashes($surfsUpOptions_popup['point3']);
            $formTitle = addslashes($surfsUpOptions_popup['form-title']);
            $formDesc = addslashes($surfsUpOptions_popup['form-desc']);
            $nameDefault = addslashes($surfsUpOptions_popup['name-default']);
            $emailDefault = addslashes($surfsUpOptions_popup['email-default']);
            if($surfsUpOptions_popup['active_template'] == "1"){
                $classPrefix = "wp-demon-t1";
                $indexPrefix = "template1";
                $template1_html='<div class="'.$classPrefix.'-wrapper" style="box-shadow:0px 0px 5px #'.$surfsUpOptions_popup[$indexPrefix.'-bkcolor'].';background-color:#'.$surfsUpOptions_popup[$indexPrefix.'-container-bk'].'"><div id="close"><img src="wp-content/plugins/wp-demon/wp-demon-res/images/close_button.png" /></div>';
                $template1_html.='<div class="'.$classPrefix.'-pop-up">';
                $template1_html.='<div class="'.$classPrefix.'-popup-left"><div class="'.$classPrefix.'-headline"><h1 style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-title-color'].'">'.$title.'</h1></div><div class="'.$classPrefix.'-tagline"><span style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-para-color'].'">'.$shortText.'</span></div>';
                $template1_html.='<div class="'.$classPrefix.'-bullet-points">';
                $template1_html.='<ul style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-bullets-txtc'].'"><li><div class="bullet-point-image"></div>'.$point1.'</li>';
                $template1_html.='<li><div class="bullet-point-image"></div>'.$point2.'</li>';
                $template1_html.='<li><div class="bullet-point-image"></div>'.$point3.'</li>';
                $template1_html.='</ul>';
                $template1_html.='</div>';
                $template1_html.='</div> <!--Ends pop-up-left-->';
                $template1_html.='<div class="'.$classPrefix.'-popup-right" style="background:#'.$surfsUpOptions_popup[$indexPrefix.'-form-bkcolor'].';box-shadow:0px 0px 5px #'.$surfsUpOptions_popup[$indexPrefix.'-form-border'].'">';
                $template1_html.='<div class="'.$classPrefix.'-enticer">';
                $template1_html.='<div style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-form-title-color'].'">'.$formTitle.'</div>';
                $template1_html.='</div> <!--Ends Enticer-->';
                $template1_html.='<div class="'.$classPrefix.'-description">';
                $template1_html.='<div style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-form-desc-color'].'">'.$formDesc.'</div>';
                $template1_html.='</div> <!--Ends description-->';
                $template1_html.='<div class="'.$classPrefix.'-optinform">';
                $template1_html.='<form method="post" action="'.$surfsUpOptions_popup['inputsaction'].'">';
                $template1_html.='<input type="text" name="'.$inputs['name'].'"  class="input-box" value="'.$nameDefault.'" />';
                $template1_html.='<input type="text" name="'.$inputs['email'].'"  class="input-box" value="'.$emailDefault.'" />'.$fields;
                $template1_html.='<div class="submit-button-wrapper" style="display:inline-block;background:#'.$surfsUpOptions_popup[$indexPrefix.'-submit-bk'].'"><div class="submit-button-left"></div><div class="submit-button-right"></div><div class="submit-button-center"><input style="background:transparent;color:#'.$surfsUpOptions_popup[$indexPrefix.'-submit-text-color'].';height:39px;" type="submit" value="'.$surfsUpOptions_popup['submit-text'].'" /></div></div>';
                $template1_html.='</form>';
                $template1_html.='</div> <!--Ends optinform-->';
                $template1_html.='<div class="'.$classPrefix.'-formfooter">';
                $template1_html.='<p>No Spam. Promise.</p>';
                $template1_html.='</div> <!--Ends formfooter--></div> <!--Ends popup--></div> <!--Ends wrapper-->';
            }else if($surfsUpOptions_popup['active_template'] == "2"){
                $classPrefix = "wp-demon-t2";
                $indexPrefix = "template2";
                $template1_html='<div class="'.$classPrefix.'-wrapper" style="box-shadow:0px 0px 5px #'.$surfsUpOptions_popup['template2-bkcolor'].';background-color:#'.$surfsUpOptions_popup['template2-container-bk'].'"><div id="close">x</div>';
                $template1_html.='<div class="'.$classPrefix.'-pop-up">';
                $template1_html.='<div class="'.$classPrefix.'-popup-left"><div class="'.$classPrefix.'-headline"><h1 style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-title-color'].'">'.$title.'</h1></div><div class="'.$classPrefix.'-tagline"><span style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-para-color'].'">'.$shortText.'</span></div>';
                $template1_html.='<div class="'.$classPrefix.'-bullet-points">';
                $template1_html.='<ul><li style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-bullets-txtc'].'"><div class="bullet-point-image"></div>'.$point1.'</li>';
                $template1_html.='<li style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-bullets-txtc'].'"><div class="bullet-point-image"></div>'.$point2.'</li>';
                $template1_html.='<li style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-bullets-txtc'].'"><div class="bullet-point-image"></div>'.$point3.'</li>';
                $template1_html.='</ul>';
                $template1_html.='</div>';
                $template1_html.='</div> <!--Ends pop-up-left-->';
                $template1_html.='<div class="'.$classPrefix.'-popup-right">';
                $template1_html.='<div class="'.$classPrefix.'-enticer">';
                $template1_html.='<div class="title" style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-form-title-color'].'">'.$formTitle.'</div>';
                $template1_html.='</div> <!--Ends Enticer-->';
                //$template1_html.='<div class="'.$classPrefix.'-description">';
                //$template1_html.='<p style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-form-desc-color'].'">'.$formDesc.'</p>';
                //$template1_html.='</div> <!--Ends description-->';
                $template1_html.='<div class="'.$classPrefix.'-optinform">';
                $template1_html.='<form method="post" action="'.$surfsUpOptions_popup['inputsaction'].'">';
                $template1_html.='<input type="text" name="'.$inputs['name'].'"  class="input-box" value="'.$nameDefault.'" />&nbsp;';
                $template1_html.='<input type="text" name="'.$inputs['email'].'"  class="input-box" value="'.$emailDefault.'" />'.$fields;
                $template1_html.='<div class="submit-button-wrapper" style="display:inline-block;background:#'.$surfsUpOptions_popup[$indexPrefix.'-submit-bk'].'"><div class="submit-button-left"></div><div class="submit-button-right"></div><div class="submit-button-center"><input style="background:transparent;color:#'.$surfsUpOptions_popup[$indexPrefix.'-submit-text-color'].';height:39px;" type="submit" value="'.$surfsUpOptions_popup['submit-text'].'" /></div></div>';
                $template1_html.='</form>';
                $template1_html.='</div> <!--Ends optinform-->';
                $template1_html.='<div class="'.$classPrefix.'-formfooter">';
                $template1_html.='<p>No Spam. Promise.</p>';
                $template1_html.='</div><br /> <!--Ends formfooter--></div> <!--Ends popup--></div> <!--Ends wrapper-->';
            }else if($surfsUpOptions_popup['active_template'] == "3"){
                $classPrefix = "wp-demon-t3";
                $indexPrefix = "template3";
                $template1_html='<div class="'.$classPrefix.'-wrapper" style="box-shadow:0px 0px 5px #'.$surfsUpOptions_popup['template3-bkcolor'].';background-color:#'.$surfsUpOptions_popup['template3-container-bk'].'"><div id="close">x</div>';
                $template1_html.='<div class="'.$classPrefix.'-pop-up">';
                $template1_html.='<div class="'.$classPrefix.'-popup-left"><div class="'.$classPrefix.'-headline"><h1 style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-title-color'].'">'.$title.'</h1></div><div class="'.$classPrefix.'-tagline"><span style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-para-color'].'">'.$shortText.'</span></div>';
                // template3 image
                $template1_html.='<div class="'.$classPrefix.'-bullet-points"><div class="template3-image"><img width="200px" src="'.$surfsUpOptions_popup[$indexPrefix.'-image-url'].'" /></div><br />';
                $template1_html.='<ul><li style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-bullets-txtc'].'"><div class="bullet-point-image"></div>'.$point1.'</li>';
                $template1_html.='<li style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-bullets-txtc'].'"><div class="bullet-point-image"></div>'.$point2.'</li>';
                $template1_html.='<li style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-bullets-txtc'].'"><div class="bullet-point-image"></div>'.$point3.'</li>';
                $template1_html.='</ul>';
                $template1_html.='</div>';
                $template1_html.='</div> <!--Ends pop-up-left-->';
                $template1_html.='<div class="'.$classPrefix.'-popup-right">';
                $template1_html.='<div class="'.$classPrefix.'-enticer">';
                $template1_html.='<div class="title" style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-form-title-color'].'">'.$formTitle.'</div>';
                $template1_html.='</div> <!--Ends Enticer-->';
                //$template1_html.='<div class="'.$classPrefix.'-description">';
                //$template1_html.='<p style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-form-desc-color'].'">'.$formDesc.'</p>';
                //$template1_html.='</div> <!--Ends description-->';
                $template1_html.='<div class="'.$classPrefix.'-optinform">';
                $template1_html.='<form method="post" action="'.$surfsUpOptions_popup['inputsaction'].'">';
                $template1_html.='<input type="text" name="'.$inputs['name'].'"  class="input-box" value="'.$nameDefault.'" />&nbsp;';
                $template1_html.='<input type="text" name="'.$inputs['email'].'"  class="input-box" value="'.$emailDefault.'" />'.$fields;
                $template1_html.='<div class="submit-button-wrapper" style="display:inline-block;background:#'.$surfsUpOptions_popup[$indexPrefix.'-submit-bk'].'"><div class="submit-button-left"></div><div class="submit-button-right"></div><div class="submit-button-center"><input style="background:transparent;color:#'.$surfsUpOptions_popup[$indexPrefix.'-submit-text-color'].';height:39px;" type="submit" value="'.$surfsUpOptions_popup['submit-text'].'" /></div></div>';
                $template1_html.='</form>';
                $template1_html.='</div> <!--Ends optinform-->';
                $template1_html.='<div class="'.$classPrefix.'-formfooter">';
                $template1_html.='<p>No Spam. Promise.</p>';
                $template1_html.='</div><br /> <!--Ends formfooter--></div> <!--Ends popup--></div></div> <!--Ends wrapper-->';
            }else if($surfsUpOptions_popup['active_template'] == "4"){
                
                $classPrefix = "wp-demon-t4";
                $indexPrefix = "template4";
                $template1_html='<div class="'.$classPrefix.'-wrapper" style="box-shadow:0px 0px 5px #'.$surfsUpOptions_popup[$indexPrefix.'-bkcolor'].';background-color:#'.$surfsUpOptions_popup[$indexPrefix.'-container-bk'].'"><div id="close"><img src="wp-content/plugins/wp-demon/wp-demon-res/images/close_button.png" /></div>';
                $template1_html.='<div class="'.$classPrefix.'-pop-up">';
                $template1_html.='<div class="'.$classPrefix.'-popup-left"><div class="'.$classPrefix.'-headline"><h1 style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-title-color'].'">'.$title.'</h1></div><div class="'.$classPrefix.'-tagline"><span style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-para-color'].'">'.$shortText.'</span></div>';
                
                // template 4 image . 
                
                $template1_html.='<div class="'.$classPrefix.'-bullet-points"><div class="template4-image"><img width="200px" src="'.$surfsUpOptions_popup[$indexPrefix.'-image-url'].'" /></div>';
                $template1_html.='<ul style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-bullets-txtc'].'"><li><div class="bullet-point-image"></div>'.$point1.'</li>';
                $template1_html.='<li><div class="bullet-point-image"></div>'.$point2.'</li>';
                $template1_html.='<li><div class="bullet-point-image"></div>'.$point3.'</li>';
                $template1_html.='</ul>';
                $template1_html.='</div>';
                $template1_html.='</div> <!--Ends pop-up-left-->';
                $template1_html.='<div class="'.$classPrefix.'-popup-right" style="background:#'.$surfsUpOptions_popup[$indexPrefix.'-form-bkcolor'].';box-shadow:0px 0px 5px #'.$surfsUpOptions_popup[$indexPrefix.'-form-border'].'">';
                $template1_html.='<div class="'.$classPrefix.'-enticer">';
                $template1_html.='<div style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-form-title-color'].'">'.$formTitle.'</div>';
                $template1_html.='</div> <!--Ends Enticer-->';
                $template1_html.='<div class="'.$classPrefix.'-description">';
                $template1_html.='<div style="color:#'.$surfsUpOptions_popup[$indexPrefix.'-form-desc-color'].'">'.$formDesc.'</div>';
                $template1_html.='</div> <!--Ends description-->';
                $template1_html.='<div class="'.$classPrefix.'-optinform">';
                $template1_html.='<form method="post" action="'.$surfsUpOptions_popup['inputsaction'].'">';
                $template1_html.='<input type="text" name="'.$inputs['name'].'"  class="input-box" value="'.$nameDefault.'" />';
                $template1_html.='<input type="text" name="'.$inputs['email'].'"  class="input-box" value="'.$emailDefault.'" />'.$fields;
                $template1_html.='<div class="submit-button-wrapper" style="display:inline-block;background:#'.$surfsUpOptions_popup[$indexPrefix.'-submit-bk'].'"><div class="submit-button-left"></div><div class="submit-button-right"></div><div class="submit-button-center"><input style="background:transparent;color:#'.$surfsUpOptions_popup[$indexPrefix.'-submit-text-color'].';height:39px;" type="submit" value="'.$surfsUpOptions_popup['submit-text'].'" /></div></div>';
                $template1_html.='</form>';
                $template1_html.='</div> <!--Ends optinform-->';
                $template1_html.='<div class="'.$classPrefix.'-formfooter">';
                $template1_html.='<p>No Spam. Promise.</p>';
                $template1_html.='</div> <!--Ends formfooter--></div> <!--Ends popup--></div> <!--Ends wrapper-->';
            }
            return $template1_html;
        }

        function format_dead_html($str) {
            $str = htmlspecialchars($str);
            $str = str_replace(array("'", '"'), array('&#39;', '&quot;'), $str);
            return $str;
        }

            function page_list_recursive($parentid=0, $exclude='', $selected=array(),$comp) {

            
            $pages = get_pages('parent=' . $parentid . '&child_of=' . $parentid . '&exclude=' . $exclude);
            if(($parentid == 0) && (get_option('show_on_front') == 'posts'))
            {
                if (isset($selected) && in_array('25071', $selected))
                        $sel = true;
                    echo '<ul><li><input class="checkbox-select-all" type="checkbox" /> Select All </li><li><input type="checkbox" name="pages[]" id="25071'.$comp.'" value="25071"' . (($sel) ? ' checked="checked"' : '') . ' /> <label for="25071'.$comp.'">' . wp_specialchars("Front Page") . '</label></li></ul>';
            }
            if (count($pages) > 0) {
                $str = '<ul>';
                if($parentid>0)
                     $str = '<ul style="margin-left:18px;margin-top:3px;margin-bottom:3px;">';
                foreach ($pages as $p) {
                    $sel = false;
                    if (isset($selected) && in_array($p->ID, $selected))
                        $sel = true;
                    $str .= '
			<li><input type="checkbox" name="pages[]" value="' . $p->ID . '" id="pageid_' . $p->ID .$comp. '"' . (($sel) ? ' checked="checked"' : '') . ' /> <label for="pageid_' . $p->ID .$comp. '">' . wp_specialchars($p->post_title) . '</label>' . $this->page_list_recursive($p->ID, $exclude, $selected,$comp) . '</li>';
                }
                $str .= '
		</ul>';
                return $str;
            }
        }
         
        function cat_list_recursive($parentid=0, $selected=array(),$comp) {
            $cats = get_categories('hide_empty=0&child_of=' . $parentid . '&parent=' . $parentid);
            if (count($cats) > 0) {
                $str = '<ul><li><input class="checkbox-select-all" type="checkbox" /> Select All </li>';
                if($parentid>0)
                     $str = '<ul style="margin-left:18px;margin-top:3px;margin-bottom:3px;"><li><input class="checkbox-select-all" type="checkbox" /> Select All </li>';
                foreach ($cats as $c) {
                    $sel = false;
                    if (isset($selected) && in_array($c->cat_ID, $selected))
                        $sel = true;
                    $str .= '
					<li><input type="checkbox" name="categories[]" value="' . $c->cat_ID . '" id="catid_' . $c->cat_ID .$comp. '"' . (($sel) ? ' checked="checked"' : '') . ' /> <label for="catid_' . $c->cat_ID .$comp. '">' . wp_specialchars($c->cat_name) . '</label>' . $this->cat_list_recursive($c->cat_ID, $selected) . '</li>';
                }
                $str .= '</ul>';
                
                return $str;
            }
            return '';
        }

        function cat_pages_list_recursive($parentid=0, $selected=array(),$comp) {
            $cats = get_categories('hide_empty=0&child_of=' . $parentid . '&parent=' . $parentid);
            if (count($cats) > 0) {
                $str = '<ul><li><input class="checkbox-select-all" type="checkbox" /> Select All </li>';
                if($parentid>0)
                     $str = '<ul style="margin-left:18px;margin-top:3px;margin-bottom:3px;"><li><input class="checkbox-select-all" type="checkbox" /> Select All </li>';
                foreach ($cats as $c) {
                    $sel = false;
                    if (isset($selected) && in_array($c->cat_ID, $selected))
                        $sel = true;
                    $str .= '
					<li><input type="checkbox" name="cat_pages[]" value="' . $c->cat_ID . '" id="catpid_' . $c->cat_ID .$comp. '"' . (($sel) ? ' checked="checked"' : '') . ' /> <label for="catpid_' . $c->cat_ID .$comp. '">' . wp_specialchars($c->cat_name) . '</label>' . $this->cat_pages_list_recursive($c->cat_ID, $selected) . '</li>';
                }
                $str .= '</ul>';
                return $str;
            }
            return '';
        }
        function in_assoc_array($id, $arr)
        {
            if($arr == null)
                return "";
            $i = false;
            foreach( $arr as $value)
            {
                if($id == $value)
                {
                    
                    $i = true;
                }
            }
            
            return $i;
        }
        function getConfig($place)
        {
            $i = "null";
            global $wp_query;
            $surfsUpMainOptions = $this->fetchSurfsUpOptions('');
                    foreach($surfsUpMainOptions[$place] as $value)
                    {
                        
                        $arr = $this->fetchSurfsUpOptions($value);
                        $pages = unserialize($arr['pages']);
                        $cats = unserialize($arr['categories']);
                        $cat_pages = unserialize($arr['cat_pages']);
                        
                        if(isset($arr['pages']) && !is_single() && !is_category()){
                            if($this->in_assoc_array($wp_query->post->ID,$pages))
                            {
                                //echo "is page";
                                $i = json_encode($arr);
                                break;
                            }
                            else if($this->in_assoc_array('25071',$pages) && is_front_page())
                            {
                                //echo "is home page";
                                $i = json_encode($arr);
                                break;
                            }
                            else if($this->in_assoc_array(get_option('page_for_posts'),$pages) && is_home())
                            {
                                //echo "is posts page";
                                $i = json_encode($arr);
                                break;
                            }
                        }

                        else if(is_single() && isset($arr['categories']))
                        {
                            //echo "is single post";
                            $cat_id = get_the_category($wp_query->post->ID);
                            //print_r($cat_id);
                            $cat_id = $cat_id[0]->cat_ID;

                            if($this->in_assoc_array($cat_id,$cats))
                            {

                                $i = json_encode($arr);
                                
                            }

                        }
                        else if(is_category() && isset($arr['cat_pages']))
                        {
                            //echo "is category page<br>";

                            foreach($cat_pages as $cat)
                            {
                                
                                if(is_category($cat))
                                {
                                    $i = json_encode($arr);
                                    break;
                                }
                            }
                        }
                    }

            return $i;
        }
                
        function enquequeScripts() 
        {            
            $e=get_option('hover_cart_license');
            if (!is_admin()) {
                wp_enqueue_script( 'jquery' );
            }
            wp_enqueue_script('surfs-setup-js', '/wp-content/plugins/wp-demon/wp-demon-res/wp-demon.js');
            wp_enqueue_script('surfs-jqueryui', '/wp-content/plugins/wp-demon/wp-demon-res/jqueryUI/js/jCookie.js');
            wp_enqueue_script('surfs-jqueryui', '/wp-content/plugins/wp-demon/wp-demon-res/jqueryUI/js/jquery-ui-1.8.6.custom.min.js');
            ?>
            <script type="text/javascript">
                var bottom_config =
                <?php
                    $i = $this->getConfig('bottom');
                    echo $i;
                ?>;
                var top_config =
                <?php
                    $i = $this->getConfig('top');
                    echo $i;
                ?>;
                var center_config =
                <?php
                    $i = $this->getConfig('center');
                    echo $i;
                ?>;
                if(center_config != null){
                center_config['formhtml']='<?php echo $this->generatePopupForm(); ?>';
                }
            </script>
            <?php
            wp_register_style('surfs-style-css', '/wp-content/plugins/wp-demon/wp-demon-res/wp-demon.css');
            wp_enqueue_style('surfs-style-css');
            wp_register_style('surfs-jqueryUI-css', '/wp-content/plugins/wp-demon/wp-demon-res/jqueryUI/css/flick/jquery-ui-1.8.6.custom.css');
            wp_enqueue_style('surfs-jqueryUI-css');
        }
        
        function surfs_up_options_page() {
            // Displays form
            // Retrieves values from database for the form and saves the changed data.
            ?><?php
            if (!current_user_can('manage_options')) {
                wp_die(__('You do not have sufficient permissions to access this page.'));
            }
            else {
                //wp_register_style('surfs-admin-style-css', '/wp-content/plugins/wp-demon/wp-demon-res/surfs-admin.css');
                // wp_enqueue_style('surfs-admin-style-css');
                $surfsUpOptions_btn_text = $this->fetchSurfsUpOptions('button_text');
                $surfsUpOptions_btn = $this->fetchSurfsUpOptions('button');
                $surfsUpOptions_pf = $this->fetchSurfsUpOptions('product_features');
                $surfsUpOptions_popup = $this->fetchSurfsUpOptions('popup');
                $surfsUpOptions_popupform = get_option($this->dbOptionName_popupformhtml);

            // TODO: include here.
                $opts = array(
                              'http'=>array(
                                            'method'=>"GET",
                                            'header'=>"Accept-language: en\r\n" .
                                            "Cookie: foo=bar\r\n"
                                            )
                              );
                
                $context = stream_context_create($opts);
                
                // Open the file using the HTTP headers set above
                error_reporting(0);
                $file = file_get_contents('http://wp-demon.com/wp-demon-ver.txt', false, $context);
                function plugin_get_version() {
                    $plugin_data = get_plugin_data(__FILE__);
                    $plugin_version = $plugin_data['Version'];
                    return $plugin_version;
                }
                $ver = plugin_get_version();
                include('settingsPage.php');
            }
        }

        function saveOptions() {
              error_reporting(0);
              if (isset($_POST['name']) && ($_POST['name'] != 'popup')) {
                  foreach ($_POST as $key => $value) {
                        $surfsUpOptions[$key] = stripslashes($value);
                  }
                  if(isset($_POST['pages'])){
                        $surfsUpOptions['pages'] = serialize($_POST['pages']);
                  }
                  if(isset($_POST['categories']))
                      $surfsUpOptions['categories'] = serialize($_POST['categories']);
                  if(isset($_POST['cat_pages']))
                      $surfsUpOptions['cat_pages'] = serialize($_POST['cat_pages']);

                  $updated = update_option($surfsUpOptions['db'], $surfsUpOptions);


                  $this->deactivate($surfsUpOptions['name']);
                  $surfsUpMainOptions = $this->fetchSurfsUpOptions('');
                  $conflict = false;
                    $with = array();
                  if(!in_array($surfsUpOptions['name'],$surfsUpMainOptions[$surfsUpOptions['placeholder']]))
                  {

                      foreach($surfsUpMainOptions[$surfsUpOptions['placeholder']] as $key => $value){
                          $temp = $this->fetchSurfsUpOptions($value);
                          if($surfsUpOptions['pages'])
                          foreach(unserialize($surfsUpOptions['pages']) as $page_id => $page)
                          {

                              if(in_array($page,unserialize($temp['pages'])))
                              {
                                  $confict = true;
                                    $with['name'] = $temp['formal-name'];
                                    $with['type'] = "Page";
                                  break;
                              }
                          }
                            if($conflict == true)
                                    break;
                            if($surfsUpOptions['categories'])
                          foreach(unserialize($surfsUpOptions['categories']) as $cat_id => $cat)
                          {
                              if(in_array($cat,unserialize($temp['categories'])))
                              {
                                  $confict = true;
                                    $with['name'] = $temp['formal-name'];
                                    $with['type'] = "Posts ";
                                    break;
                              }
                          }
                            if($conflict)
                                    break;
                            if($surfsUpOptions['cat_pages'])
                          foreach(unserialize($surfsUpOptions['cat_pages']) as $cp_id => $cp)
                          {
                              if(in_array($cp,unserialize($temp['cat_pages'])))
                              {
                                  $confict = true;
                                    $with['name'] = $temp['formal-name'];
                                    $with['type'] = "Category Page";
                                    break;
                              }
                          }
                            if($conflict)
                                    break;
                      }
                      if(!$confict){
                        $surfsUpMainOptions[$surfsUpOptions['placeholder']][] = $surfsUpOptions['name'];

                        $updated = update_option($this->dbOptionName, $surfsUpMainOptions);
                        echo "clear";
                      }
                      else
                      {
                          echo "<b>".$surfsUpOptions['formal-name']."</b> is competing for same position on a same <b>".$with['type']."</b> with <b>".$with['name'].".</b><br /><br /> <i>Resolve conflict by changing position or unchecking common page of either component.</i><br />".'<span style="color:red;font-weight:bold;">Changes NOT saved.</span>';
                      }   
                  }
              }
              else if($_POST['license-email'])
              {
                    update_option('hover_cart_license',$_POST['license-email']);
                    echo "clear";
              }
              else {
                  update_option($this->dbOptionName_popupformhtml, $_POST['popupformhtml']);
                  foreach ($_POST as $key => $value) {
                      if (($key != 'ffn') && ($key != 'ffv') && ($key != 'popupformhtml') && ($key != 'inpus') && ($key != 'ffi') ) {
                            $surfsUpOptions[$key] = stripslashes($value);
                      }
                  }

                  $surfsUpOptions['pages'] = serialize($_POST['pages']);
                  $surfsUpOptions['categories'] = serialize($_POST['categories']);
                  $surfsUpOptions['cat_pages'] = serialize($_POST['cat_pages']);

                  $updated = update_option($surfsUpOptions['db'], $surfsUpOptions);

                  if (count($_POST['ffn']) == count($_POST['ffv'])) {
                      $ctr = count($_POST['ffn']);
                      $ff = array();
                      for ($i = 0; $i < $ctr; $i++) {
                          $_POST['ffn'][$i] = stripslashes($_POST['ffn'][$i]);
                          $_POST['ffv'][$i] = stripslashes($_POST['ffv'][$i]);
                          $ff[$_POST['ffn'][$i]] = $_POST['ffv'][$i];
                      }
                  }


                  $u4 = update_option($this->dbOptionName_popupffi, $_POST['ffi']);
                  $u5 = update_option($this->dbOptionName_popupff, $ff);
                  $in = get_option($this->dbOptionName_popupinputs);

                  $surfsUpMainOptions = $this->fetchSurfsUpOptions('');


                  foreach ($surfsUpMainOptions as $key => $value) {
                      if ($value == $surfsUpOptions['name']) {
                          $surfsUpMainOptions[$key] = 'none';
                          break;
                      }
                  }

                  if(!in_array($surfsUpOptions['name'],$surfsUpMainOptions[$surfsUpOptions['placeholder']]))
                    $surfsUpMainOptions[$surfsUpOptions['placeholder']][] = $surfsUpOptions['name'];
                  $updated = update_option($this->dbOptionName, $surfsUpMainOptions);
                  echo "clear";
              }
              exit;
          }

          function deactivate($comp) {
              $surfsUpOption = $this->fetchSurfsUpOptions('');

              if (isset($_POST['component']))
              {
                  if(is_array($surfsUpOption))
                  foreach($surfsUpOption as $key => $value)
                  {
                      if(is_array($value))
                      foreach($value as $subkey => $v )
                      {
                          if($v == $_POST['component'])
                          {
                              unset($surfsUpOption[$key][$subkey]);
                          }
                      }
                  }
              }
              else if($comp)
              {
                  if(is_array($surfsUpOption))
                  foreach($surfsUpOption as $key => $value)
                  {
                      if(is_array($value))
                      foreach($value as $subkey => $v )
                      {
                          if($v == $comp)
                          {
                              unset($surfsUpOption[$key][$subkey]);
                          }
                      }
                  }
              }
              update_option($this->dbOptionName, $surfsUpOption);
          }

      }

      //class end.
  }

if (class_exists("SurfsUp")) {
  $surfsUp_obj = new SurfsUp();
}

//Actions
if (isset($surfsUp_obj)) {

  add_action('wp_head', array(&$surfsUp_obj, 'enquequeScripts'), 1);
  //add_action('admin_menu', array(&$surfsUp_obj, 'add_surfs_up_menu'));
  add_action('admin_menu', 'SurfsUp_ap');
  add_action('activate_wp-demon/wp-demon.php', array(&$surfsUp_obj, 'init'));
  add_action('wp_ajax_surfs', array(&$surfsUp_obj, 'saveOptions'));
  add_action('wp_ajax_deact', array(&$surfsUp_obj, 'deactivate'));
}
//
//Initialize the admin panel
if (!function_exists("SurfsUp_ap")) {

    function SurfsUp_ap() {
        global $surfsUp_obj;
        if (!isset($surfsUp_obj)) {
            return;
        }
        if (function_exists('add_options_page')) {
            $plugin_page_surfsUp = add_options_page('WP Demon Options', 'WP Demon', 9,
            basename(__FILE__), array(&$surfsUp_obj, 'surfs_up_options_page'));
            add_action("admin_print_styles-$plugin_page_surfsUp", 'surfsUpAdminStyle');
        }
    } //function SurfsUp_ap ends.
}// if condition for function exists ends.

//Inject style in admin panel

if (!function_exists('surfsUpAdminStyle')) {
    function surfsUpAdminStyle() {
        wp_enqueue_style('surfs-admin-style-ui', '/wp-content/plugins/wp-demon/wp-demon-res/jqueryUI/css/flick/jquery-ui-1.8.6.custom.css');
        wp_enqueue_style('surfs-admin-style', '/wp-content/plugins/wp-demon/wp-demon-res/surfs-admin.css');
        wp_enqueue_style('surfs-colorpicker-style', '/wp-content/plugins/wp-demon/wp-demon-res/jqueryUI/colorpicker/css/colorpicker.css');
    }
}

?>
