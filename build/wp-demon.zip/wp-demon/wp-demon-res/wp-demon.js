 (function($){
  $.fn.center = function(){
  return this.each(function(){
                   var windowHeight = $(window).height();
                   var windowWidth = $(window).width();
                   var elemHeight = $(this).height();
                   var elemWidth = $(this).width();
                   var topVal = (windowHeight - elemHeight)/2 +window.pageYOffset;
                   var leftVal = (windowWidth - elemWidth)/2 + window.pageXOffset;
                   //alert(windowHeight + "/2 -" + elemHeight +"/2 =" + (windowHeight-elemHeight)/2);
                   topVal = topVal < 0 ? 20 : topVal;
                   leftVal = leftVal < 0 ? 20 : leftVal;
                   $(this).css("top",topVal);
                   $(this).css("left",leftVal);
                   });
  }
  })(jQuery);
function bottom_bar(config){
    var image_height = 0;
    var c;
    if(!config['opacity'])
        {
            config['opacity'] = 0.4;
        }
    if(config['name']=='button' | config['name']=='button_text'){
    jQuery(document).ready(function(){
        $holder_bottom=bottom_display(config);
        image_height=config['slideout_height'];

        //alert(image_height);
        config['animation_delay'] *= 1000;
        setTimeout(function(){$holder_bottom.css("display", "block").stop().animate({ bottom : 0},1000); },config['animation_delay']);
        setTimeout(function(){$holder_bottom.stop().animate({"opacity": config['opacity'],"bottom" : -1*image_height/2},"slow")},parseInt(config['animation_delay'])+4000);
        $handle_bottom.hover(function(){$holder_bottom.stop().animate({"opacity": 1,"bottom" : 0},"fast")
            }, function(){$holder_bottom.stop().animate({"opacity": config['opacity'],"bottom" : -1*image_height/2},"fast")
            });
        });

        if((config['name']=='button_text') && (config['onscreen-time'] > -1))
        {
            height = $holder_bottom.height();
            setTimeout(function(){$holder_bottom.stop().animate({'bottom':-1*height},function(){$holder_bottom.hide();jQuery('#page-adjust').hide();})},config['onscreen-time']*1000);
        }
    }
    else{
        jQuery(document).ready(function(){
        $holder_bottom=bottom_display(config);
        image_height=jQuery('#product_features').height();
        jQuery('body').css("height", jQuery('body').outerHeight(true)+image_height/2 + "px");
        setTimeout(function(){	$holder_bottom.css("display", "block").stop().animate({ bottom : 0},1000); },config['animation_delay']);
        setTimeout(function(){$holder_bottom.stop().animate({"opacity": 1,"bottom" : -1*config['slideout_height']},"slow")},parseInt(config['animation_delay'])+4000);
        $handle_bottom.hover(function(){$holder_bottom.stop().animate({"opacity": 1,"bottom" : 0},"fast")
            }, function(){$holder_bottom.stop().animate({"opacity": 1,"bottom" : -1*config['slideout_height']},"fast")
            });
        });
    }
}
function top_bar(config){
    if(!config['opacity'])
        {
            config['opacity'] = 0.4;
        }
    var image_height = 0;
    jQuery(document).ready(function(){
        $holder_top=top_display(config);
        image_height=config['slideout_height'];
        //jQuery('body').css("height", jQuery('body').outerHeight(true)+image_height + "px");
        config['animation_delay'] *= 1000;
        jQuery('body').prepend('<div id="page-adjust-top" style="background-color:inherit;height:0px;width:100%"></div>');
        setTimeout(function(){$holder_top.css("display", "block").stop().animate({top : 0},1000);},config['animation_delay']);
        setTimeout(function(){$holder_top.stop().animate({"opacity": config['opacity'],"top" : -1*image_height/2},"slow")},parseInt(config['animation_delay'])+4000);
        $handle_top.hover(function(){$holder_top.stop().animate({"opacity": 1,"top" : 0},"fast")
            }, function(){$holder_top.stop().animate({"opacity": config['opacity'],"top" : -1*image_height/2},"fast")
            });
    });
    if((config['name']=='button_text') && (config['onscreen-time'] > -1))
    {
        height = $holder_top.height();
        setTimeout(function(){$holder_top.stop().animate({'top':-1*height},function(){$holder_top.hide();jQuery('#page-adjust-top').hide();})},config['onscreen-time']*1000);
    }
}
function bottom_display(config){
    if(config['name']=='button_text'){
        config['bold'] = config['bold']? config['bold'] : '';
        config['italic'] = config['italic']? config['italic'] : '';
        config['underline'] = config['underline']? config['underline'] : '';
        config['bt-bcolor'] = config['bt-bcolor'] != '' ? config['bt-bcolor'] : "transparent";
        config['bt-color'] = config['bt-color'] != '' ? config['bt-color'] : "transparent";
        //css fix for setting width:auto; bug due to "right:0px"
        widthStyle="";positionCss = "";
        subholderCss = "";
        if(config['bt-width']=="auto"){
            if(config['image_position'] == "left"){
                widthStyle = ";left:0px;right:auto";
            }
            else if(config['image_position'] == "right")
                widthStyle = ";left:auto;right:0px"
            else if(config['image_position'] == "center")
                widthStyle = ";left:auto;right:auto";
        }else{
            widthStyle=";width:100%";
        }
        link = new Array();
        if(config['image_link'])
        {
            link[0] = "<a style='color:inherit' target=\"_blank\" href=\""+config['image_link']+"\">";
            link[1] = "</a>";
        }else{
            link = ["",""];
        }
        if(config['image']){
            jQuery('body').append('<div id="button-text-holder" style="width:'+config['bt-width']+widthStyle+';display:none;bottom:-400px;"><div class="offers-close" style="z-index:999999">[x]</div><center>'+ link[0]+config['image_link']+'"><img id="img_button" style="float : '  +config['image_position']+'" src="'+config['image']+'">'+link[1]+'</center></div>');
        }else{
            if(config['text_position'] == "center"){
                if(config['bt-width'] == "100%"){
                    positionCss = "left:0px;right:auto;";
                    subholderCss = ";text-align:center;right:auto";
                }else
                    positionCss = "left:50%;right:auto;";
            }else if(config['text_position'] == "left"){
                positionCss = "right:auto; left:0px;";
            }else{
                positionCss = "right:0px; left:auto;";
            }
            jQuery('body').append('<div id="button-text-holder" style="display:none;bottom:-400px;width:'+config['bt-width']+widthStyle+';'+positionCss+'"><div class="offers-shadow-top"></div><div class="offers-close" style="z-index:999999">[x]</div></div>');
        }
        height = 0;
        c = setInterval(function(){height=jQuery('#button-text-holder').height();if(height != 0) {jQuery('#page-adjust').height(height-config['slideout_height']);clearInterval(c);}},1000);
        jQuery('body').append('<div id="page-adjust" style="width:100%;"></div>');
        $configured_subholder_bottom = jQuery("#button-text-holder");
        if(config['text']){
            $configured_subholder_bottom.css("background-color",'#'+config['bt-bcolor']); //to add background color
            $configured_subholder_bottom.append('<div id="button-text" style="position:relative;text-decoration:none;float:'+ config['text_position'] +';color:#'+config['bt-color']+';padding:'+config['padding']+'px;font-size:'+config['bt-size']+'px;'+config['bold']+config['italic']+config['underline']+subholderCss+'">'+link[0]+config['text']+link[1]+'</div>');
            $handle_bottom = jQuery("#button-text-holder");
        }else{
            $handle_bottom = jQuery("#img_button");
        }
        jQuery('.offers-close').click(function(){jQuery('#button-text-holder').fadeOut();jQuery('#page-adjust').hide()});
    }
    if(config['name']=='button'){
        positionCss = "";
        if(config['image_position'] == "center"){
            positionCss = "width:100%;text-align:center;";
        }else if(config['image_position'] == "left"){
            positionCss = "right:auto; left:0px;";
        }else{
            positionCss = "right:0px; left:auto;";
        }
        jQuery('body').append('<div id="button-holder" style="'+positionCss+'display:none;bottom:-400px">'+ '<a target="_blank" href="'+config['image_link']+'"><img id="img_button" src="'+config['image']+'"></a></div>');
        //alert(jQuery('#image_button').height());
        $configured_subholder_bottom = jQuery("#button-holder");
        $handle_bottom = jQuery("#img_button");
    }    

    return $configured_subholder_bottom;
}

function top_display(config){
    if(config['name']=='button_text'){
        config['bold'] = config['bold']? config['bold'] : '';
        config['italic'] = config['italic']? config['italic'] : '';
        config['underline'] = config['underline']? config['underline'] : '';
        config['bt-bcolor'] = config['bt-bcolor'] != '' ? config['bt-bcolor'] : "transparent";
        config['bt-color'] = config['bt-color'] != '' ? config['bt-color'] : "transparent";
        //css fix for setting width:auto; bug due to "right:0px"
        widthStyle="";positionCss = "";
        subholderCss = "";
        if(config['bt-width']=="auto"){
            if(config['image_position'] == "left"){
                widthStyle = ";left:0px;right:auto";
            }
            else if(config['image_position'] == "right")
                widthStyle = ";left:auto;right:0px"
                else if(config['image_position'] == "center")
                    widthStyle = ";left:auto;right:auto";
        }else{
            widthStyle=";width:100%";
        }
        link = new Array();
        if(config['image_link'])
        {
            link[0] = "<a style='color:inherit' target=\"_blank\" href=\""+config['image_link']+"\">";
            link[1] = "</a>";
        }else{
            link = ["",""];
        }
        
        if(config['image']){
            jQuery('body').prepend('<div id="button-text-top-holder" style="width:'+config['bt-width']+widthStyle+';display:none;top:-400px;"><div class="offers-close" style="z-index:999999">[x]</div><center>'+ link[0]+'<img id="img_button-top" style="float : '  +config['image_position']+'" src="'+config['image']+'">'+link[1]+'</center></div>');
        }else{
            if(config['text_position'] == "center"){
                if(config['bt-width'] == "100%"){
                    positionCss = ";left:0px;right:auto;";
                    subholderCss = ";text-align:center;right:auto";
                }else
                    positionCss = ";left:50%;right:auto;";
            }else if(config['text_position'] == "left"){
                positionCss = ";right:auto; left:0px;";
            }else{
                positionCss = ";right:0px; left:auto;";
            }
            jQuery('body').prepend('<div id="button-text-top-holder" style="'+subholderCss+'display:none;top:-400px;width:'+config['bt-width']+widthStyle+positionCss+'"><div class="offers-shadow-bottom" style="z-index:999999"></div><div class="offers-close">[x]</div></div>');
        }
        c = setInterval(function(){height=jQuery('#button-text-top-holder').height();if(height != 0) {jQuery('#page-adjust-top').height(height-config['slideout_height']);clearInterval(c);}},1000);
        jQuery('body').append('<div id="page-adjust-top" style="width:100%;"></div>');
        $configured_subholder = jQuery("#button-text-top-holder");
        if(config['text']){
            $configured_subholder.css("background-color",'#'+config['bt-bcolor']); //to add background color
            $configured_subholder.append('<div id="button-text-top" style="text-decoration:none;float:'+ config['text_position'] +';color:#'+config['bt-color']+';padding:'+config['padding']+'px;font-size:'+config['bt-size']+'px;'+config['bold']+config['italic']+config['underline']+'">'+link[0]+config['text']+link[1]+'</div>');
            $handle_top = jQuery("#button-text-top-holder");
        }else{
            $handle_top = jQuery("#img_button-top");
        }
        jQuery('.offers-close').click(function(){jQuery('#button-text-top-holder').fadeOut();jQuery('#page-adjust-top').hide()});
    }
    if(config['name']=='button'){
        if(config['image_position'] == "center"){
            positionCss = "width:100%;text-align:center;";
        }else if(config['image_position'] == "left"){
            positionCss = "right:auto; left:0px;";
        }else{
            positionCss = "right:0px; left:auto;";
        }
        jQuery('body').append('<div id="button-holder-top" style="display:none;top:-400px;'+positionCss+'">'+ '<a target="_blank" href="'+config['image_link']+'"><img id="img_button-top"  src="'+config['image']+'"></a></div>');
        $configured_subholder = jQuery("#button-holder-top");
        $handle_top = jQuery("#img_button-top");
    }
    return $configured_subholder;
}

function popup(config){
    config['animation_delay'] *= 1000;
    if(config['active_template']=='1' || config['active_template']=='2' || config['active_template']=='3' || config['active_template']=='4')
    {
        content_holder_height = 328;
        content_holder_width = 675;
        dummy_div_top = 2;
        glass_left=1;
    
        //config['template1-bullets-txtc'] = config['template1-bullets-txtc'] ? config['template1-bullets-txtc'] : "transparent";
        str = '<div id="lightbox-wrapper" style="display:none;"><div id="popup-wrapper">'+config['formhtml']+'</div></div>';
        //        str = '<div id="lightbox-wrapper" style="display:none;"><div id="popup-wrapper">testing</div></div>';
        jQuery('body').prepend(str);
    }
    jQuery('.input-box').focus(function(){

        tmp = jQuery(this).val();
        jQuery(this).val('');
    });
    jQuery('.input-box').blur(function(){
        if(jQuery(this).attr('name')=='name' && jQuery(this).val()=='')
            {
                jQuery(this).val(config['name-default']);
            }
        else if (jQuery(this).attr('name')=='email' && jQuery(this).val()=='')
            jQuery(this).val(config['email-default']);
    });
        //jQuery('#popup-wrapper').append(config['formhtml']);
        //<div class="ui-widget-overlay"></div>
        jQuery('#close,#lightbox-wrapper').click(function(e){jQuery('#lightbox-wrapper').fadeOut('fast')});
        jQuery('#popup-wrapper').click(function(e){e.stopPropagation();});
        
        rearrange(config['active_template']);

        setTimeout(function(){

        jQuery('#lightbox-wrapper').fadeIn("fast");
        },config['animation_delay']);
    
        jQuery(document).keyup(function(e) {
                               if (e.keyCode == 27) {jQuery('#lightbox-wrapper').fadeOut('fast');  }   // esc
                      });
        //jQuery('#lightbox-wrapper').prepend(jQuery('#popup-wrapper'));
}
var elemWidth = 0;
var elemHeight = 0;
function rearrange(i)
{
    //alert('rearrange called');
    //jQuery('#wp-demon-t'+i+'-wrapper').center();
    //jQuery('#popup-wrapper').css('left', (jQuery(window).width()-$(this).outerWidth())/2);
    var windowHeight = jQuery(window).height();
    var windowWidth = jQuery(window).width();
    elem = jQuery('.wp-demon-t'+i+'-wrapper');
    if(elemWidth == 0){
    elemHeight = elem.outerHeight(true);
    elemWidth = elem.outerWidth(true);
    }
    
    var topVal = (windowHeight - elemHeight)/2 ;
    var leftVal = (windowWidth - elemWidth)/2 ;
    topVal = topVal < 0 ? 20 : (topVal);
    leftVal = leftVal < 0 ? 20 : leftVal;
    jQuery('#popup-wrapper').css("top",topVal);
    jQuery('#popup-wrapper').css("left",leftVal);
    
}
function close_cmp(id)
{
    if(id == 'pf')
        {
            image_height=jQuery('#product_features').height();
            jQuery('#product_features').fadeOut("fast");

            jQuery('body').css("height", jQuery('body').outerHeight(true)-image_height/2 + "px");
        }
}

jQuery(document).ready(function(){
function getMaxZ(){
    var maxZ = Math.max.apply(null,jQuery.map(jQuery('body *'), function(e,n){
        if(jQuery(e).css('position')=='absolute')
            return parseInt(jQuery(e).css('z-index'))||1 ;
        })
        );
       return(maxZ);
    }

try
    {
        if(top_config){
            str = "wpdemon-" + top_config['name'];
            //alert(str);
            //alert(jQuery.cookie("wpdemon-"+top_config['name']));
            if(jQuery.cookie("wpdemon-"+top_config['name']) != null && jQuery.cookie("wpdemon-"+top_config['name']) > 0)
            {
            }else
            {    	    
                jQuery.cookie("wpdemon-"+top_config['name'],top_config['cookie-timeout'],{expires: top_config['cookie-timeout']})
                top_bar(top_config);
            }
        }
        if(bottom_config){
            str = "wpdemon-" + bottom_config['name'];
            //alert(str);
            //alert(jQuery.cookie("wpdemon-"+bottom_config['name']));
            if(jQuery.cookie("wpdemon-"+bottom_config['name']) != null && jQuery.cookie("wpdemon-"+bottom_config['name']) > 0)
            {
                //bottom_bar(bottom_config);
                //alert(jQuery.cookie("wpdemon-"+bottom_config['name']));
            }else
            {
                //alert("Time out in config : " + bottom_config['cookie-timeout']);
                jQuery.cookie(str,bottom_config['cookie-timeout'],{expires: bottom_config['cookie-timeout']})
                bottom_bar(bottom_config);
            }    
            //bottom_bar(bottom_config);
        }
        if(center_config){
            if(jQuery.cookie("wpdemon-"+center_config['name']) != null && jQuery.cookie("wpdemon-"+center_config['name']) > 0)
            {
                //popup(center_config);
                //alert(jQuery.cookie("wpdemon-"+center_config['name']));
            }else
            {
                jQuery.cookie("wpdemon-"+center_config['name'],center_config['cookie-timeout'],{expires: center_config['cookie-timeout']})
                popup(center_config);
            }
        }
    }catch(e)
    {
    //alert(e);
    }
    jQuery(window).resize(rearrange);
                       jQuery(document).pngFix();
});
(function($) {
 
 jQuery.fn.pngFix = function(settings) {
 
 // Settings
 settings = jQuery.extend({
                          blankgif: 'blank.gif'
                          }, settings);
 
 var ie55 = (navigator.appName == "Microsoft Internet Explorer" && parseInt(navigator.appVersion) == 4 && navigator.appVersion.indexOf("MSIE 5.5") != -1);
 var ie6 = (navigator.appName == "Microsoft Internet Explorer" && parseInt(navigator.appVersion) == 4 && navigator.appVersion.indexOf("MSIE 6.0") != -1);
 
 if (jQuery.browser.msie && (ie55 || ie6)) {
 
 //fix images with png-source
 jQuery(this).find("img[src$=.png]").each(function() {
                                          
                                          jQuery(this).attr('width',jQuery(this).width());
                                          jQuery(this).attr('height',jQuery(this).height());
                                          
                                          var prevStyle = '';
                                          var strNewHTML = '';
                                          var imgId = (jQuery(this).attr('id')) ? 'id="' + jQuery(this).attr('id') + '" ' : '';
                                          var imgClass = (jQuery(this).attr('class')) ? 'class="' + jQuery(this).attr('class') + '" ' : '';
                                          var imgTitle = (jQuery(this).attr('title')) ? 'title="' + jQuery(this).attr('title') + '" ' : '';
                                          var imgAlt = (jQuery(this).attr('alt')) ? 'alt="' + jQuery(this).attr('alt') + '" ' : '';
                                          var imgAlign = (jQuery(this).attr('align')) ? 'float:' + jQuery(this).attr('align') + ';' : '';
                                          var imgHand = (jQuery(this).parent().attr('href')) ? 'cursor:hand;' : '';
                                          if (this.style.border) {
                                          prevStyle += 'border:'+this.style.border+';';
                                          this.style.border = '';
                                          }
                                          if (this.style.padding) {
                                          prevStyle += 'padding:'+this.style.padding+';';
                                          this.style.padding = '';
                                          }
                                          if (this.style.margin) {
                                          prevStyle += 'margin:'+this.style.margin+';';
                                          this.style.margin = '';
                                          }
                                          var imgStyle = (this.style.cssText);
                                          
                                          strNewHTML += '<span '+imgId+imgClass+imgTitle+imgAlt;
                                          strNewHTML += 'style="position:relative;white-space:pre-line;display:inline-block;background:transparent;'+imgAlign+imgHand;
                                          strNewHTML += 'width:' + jQuery(this).width() + 'px;' + 'height:' + jQuery(this).height() + 'px;';
                                          strNewHTML += 'filter:progid:DXImageTransform.Microsoft.AlphaImageLoader' + '(src=\'' + jQuery(this).attr('src') + '\', sizingMethod=\'scale\');';
                                          strNewHTML += imgStyle+'"></span>';
                                          if (prevStyle != ''){
                                          strNewHTML = '<span style="position:relative;display:inline-block;'+prevStyle+imgHand+'width:' + jQuery(this).width() + 'px;' + 'height:' + jQuery(this).height() + 'px;'+'">' + strNewHTML + '</span>';
                                          }
                                          
                                          jQuery(this).hide();
                                          jQuery(this).after(strNewHTML);
                                          
                                          });
 
 // fix css background pngs
 jQuery(this).find("*").each(function(){
                             var bgIMG = jQuery(this).css('background-image');
                             if(bgIMG.indexOf(".png")!=-1){
                             var iebg = bgIMG.split('url("')[1].split('")')[0];
                             jQuery(this).css('background-image', 'none');
                             jQuery(this).get(0).runtimeStyle.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + iebg + "',sizingMethod='scale')";
                             }
                             });
 
 //fix input with png-source
 jQuery(this).find("input[src$=.png]").each(function() {
                                            var bgIMG = jQuery(this).attr('src');
                                            jQuery(this).get(0).runtimeStyle.filter = 'progid:DXImageTransform.Microsoft.AlphaImageLoader' + '(src=\'' + bgIMG + '\', sizingMethod=\'scale\');';
                                            jQuery(this).attr('src', settings.blankgif)
                                            });
 
 }
 
 return jQuery;
 
 };
 
 })(jQuery);

